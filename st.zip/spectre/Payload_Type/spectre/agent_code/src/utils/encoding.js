// ============================================================
// Spectre - Encoding Utilities
// Base64, hex, and buffer manipulation for Mythic protocol
// ============================================================

const EncodingUtils = {
    /**
     * Encode a string or buffer to base64.
     * Works in both Node.js and browser (Electron renderer) contexts.
     */
    toBase64: function(data) {
        if (typeof Buffer !== 'undefined') {
            // Node.js context
            if (Buffer.isBuffer(data)) return data.toString('base64');
            return Buffer.from(data, 'utf-8').toString('base64');
        }
        // Browser/renderer fallback
        return btoa(unescape(encodeURIComponent(data)));
    },

    /**
     * Decode base64 to a Buffer (Node) or string (browser).
     */
    fromBase64: function(b64) {
        if (typeof Buffer !== 'undefined') {
            return Buffer.from(b64, 'base64');
        }
        return decodeURIComponent(escape(atob(b64)));
    },

    /**
     * Convert a Buffer/Uint8Array to hex string.
     */
    toHex: function(buf) {
        if (Buffer.isBuffer(buf)) return buf.toString('hex');
        return Array.from(buf).map(b => b.toString(16).padStart(2, '0')).join('');
    },

    /**
     * Convert hex string to Buffer.
     */
    fromHex: function(hex) {
        return Buffer.from(hex, 'hex');
    },

    /**
     * Concatenate multiple Buffers.
     */
    concatBuffers: function(...buffers) {
        return Buffer.concat(buffers.map(b => Buffer.isBuffer(b) ? b : Buffer.from(b)));
    },

    /**
     * Generate random bytes using Node crypto.
     */
    randomBytes: function(length) {
        const crypto = require('crypto');
        return crypto.randomBytes(length);
    },

    /**
     * Convert a UTF-8 string to Buffer.
     */
    stringToBuffer: function(str) {
        return Buffer.from(str, 'utf-8');
    },

    /**
     * Convert a Buffer to UTF-8 string.
     */
    bufferToString: function(buf) {
        return buf.toString('utf-8');
    },

    /**
     * Encode the Mythic message format: base64(UUID + data)
     */
    encodeMythicMessage: function(uuid, data) {
        const uuidBuf = Buffer.from(uuid, 'utf-8');
        const dataBuf = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf-8');
        const combined = Buffer.concat([uuidBuf, dataBuf]);
        return combined.toString('base64');
    },

    /**
     * Decode a Mythic message: returns { uuid, data }
     * UUID is always 36 characters.
     */
    decodeMythicMessage: function(b64Message) {
        const raw = Buffer.from(b64Message, 'base64');
        const uuid = raw.slice(0, 36).toString('utf-8');
        const data = raw.slice(36);
        return { uuid, data };
    }
};
