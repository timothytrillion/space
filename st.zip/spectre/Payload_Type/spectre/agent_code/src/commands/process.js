// ============================================================
// Spectre - Process Commands
// whoami, ps (process listing), environment info
// No native addon required - uses Node.js built-ins + WMI
// ============================================================

const ProcessHandler = {
    /**
     * Get current user identity and environment info.
     */
    whoami: function() {
        const os = require('os');

        const info = {
            username: os.userInfo().username,
            uid: os.userInfo().uid,
            homedir: os.userInfo().homedir,
            hostname: os.hostname(),
            platform: os.platform(),
            arch: os.arch(),
            release: os.release(),
            uptime: os.uptime(),
            pid: process.pid,
            ppid: process.ppid,
            nodeVersion: process.version,
            execPath: process.execPath,
        };

        // Try to get domain info on Windows
        if (process.platform === 'win32') {
            info.domain = process.env.USERDOMAIN || '';
            info.logonServer = process.env.LOGONSERVER || '';
            info.userProfile = process.env.USERPROFILE || '';
            info.computerName = process.env.COMPUTERNAME || '';
        }

        let output = 'User: ' + (info.domain ? info.domain + '\\' : '') + info.username + '\n';
        output += 'Hostname: ' + info.hostname + '\n';
        output += 'OS: ' + info.platform + ' ' + info.release + ' (' + info.arch + ')\n';
        output += 'PID: ' + info.pid + ' (PPID: ' + info.ppid + ')\n';
        output += 'Process: ' + info.execPath + '\n';
        output += 'Home: ' + info.homedir + '\n';

        return {
            user_output: output,
            completed: true,
            status: 'success',
        };
    },

    /**
     * List running processes.
     * Uses WMIC on Windows (no native addon needed).
     */
    ps: function() {
        return new Promise(function(resolve) {
            const { exec } = require('child_process');

            if (process.platform === 'win32') {
                // Use WMIC for rich process data
                const cmd = 'wmic process get ProcessId,Name,ParentProcessId,CommandLine,ExecutablePath /format:csv';

                exec(cmd, {
                    timeout: 15000,
                    maxBuffer: 1024 * 1024 * 5,
                    windowsHide: true,
                }, function(error, stdout) {
                    if (error) {
                        // Fallback to tasklist
                        exec('tasklist /v /fo csv', {
                            timeout: 15000,
                            windowsHide: true,
                        }, function(err2, stdout2) {
                            resolve({
                                user_output: stdout2 || 'Failed to enumerate processes',
                                completed: true,
                                status: err2 ? 'error' : 'success',
                            });
                        });
                        return;
                    }

                    // Parse WMIC CSV output into structured data
                    const lines = stdout.trim().split('\n').filter(function(l) {
                        return l.trim().length > 0;
                    });

                    if (lines.length < 2) {
                        resolve({
                            user_output: stdout,
                            completed: true,
                            status: 'success',
                        });
                        return;
                    }

                    const processes = [];
                    const headers = lines[0].split(',');

                    for (let i = 1; i < lines.length; i++) {
                        const parts = lines[i].split(',');
                        if (parts.length >= 4) {
                            processes.push({
                                process_id: parseInt(parts[headers.indexOf('ProcessId')]) || 0,
                                name: (parts[headers.indexOf('Name')] || '').trim(),
                                parent_process_id: parseInt(parts[headers.indexOf('ParentProcessId')]) || 0,
                                bin_path: (parts[headers.indexOf('ExecutablePath')] || '').trim(),
                                command_line: (parts[headers.indexOf('CommandLine')] || '').trim(),
                            });
                        }
                    }

                    resolve({
                        completed: true,
                        status: 'success',
                        processes: processes,
                        user_output: ProcessHandler._formatProcessTable(processes),
                    });
                });
            } else {
                // Linux/macOS fallback
                exec('ps aux', { timeout: 10000 }, function(error, stdout) {
                    resolve({
                        user_output: stdout || 'Failed to list processes',
                        completed: true,
                        status: error ? 'error' : 'success',
                    });
                });
            }
        });
    },

    /**
     * Format process list as a readable table.
     */
    _formatProcessTable: function(processes) {
        let output = 'PID\tPPID\tName\t\t\tPath\n';
        output += '---\t----\t----\t\t\t----\n';

        for (let i = 0; i < processes.length; i++) {
            const p = processes[i];
            const name = (p.name || '').padEnd(24);
            output += p.process_id + '\t' + p.parent_process_id + '\t' + name + '\t' + (p.bin_path || '') + '\n';
        }

        return output;
    },

    /**
     * Get system information for initial checkin.
     */
    getSystemInfo: function() {
        const os = require('os');
        const interfaces = os.networkInterfaces();
        const ips = [];

        for (const name in interfaces) {
            const addrs = interfaces[name];
            for (let i = 0; i < addrs.length; i++) {
                if (!addrs[i].internal) {
                    ips.push(addrs[i].address);
                }
            }
        }

        return {
            user: os.userInfo().username,
            hostname: os.hostname(),
            domain: process.env.USERDOMAIN || process.env.HOSTNAME || '',
            os: 'Windows',
            arch: os.arch() === 'x64' ? 'x64' : 'x86',
            pid: process.pid,
            processName: require('path').basename(process.execPath),
            ips: ips,
            integrityLevel: 2, // Medium by default
        };
    }
};
