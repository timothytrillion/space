// ============================================================
// Spectre - Shell Command Execution
// Execute OS commands via child_process.exec
// ============================================================

const ShellHandler = {
    /**
     * Execute a shell command and return stdout/stderr.
     * Uses cmd.exe on Windows (natural for Electron context).
     */
    execute: function(params) {
        return new Promise(function(resolve, reject) {
            const { exec } = require('child_process');
            const command = params.command || params;

            const options = {
                timeout: 60000,
                maxBuffer: 1024 * 1024 * 10, // 10 MB
                windowsHide: true,
                shell: process.platform === 'win32' ? 'cmd.exe' : '/bin/sh',
            };

            exec(command, options, function(error, stdout, stderr) {
                let output = '';
                if (stdout) output += stdout;
                if (stderr) output += stderr;
                if (error && !stdout && !stderr) {
                    output = 'Error: ' + error.message;
                }

                resolve({
                    user_output: output || '(no output)',
                    completed: true,
                    status: error ? 'error' : 'success',
                });
            });
        });
    },

    /**
     * Execute a command with a specific shell (powershell, etc.)
     */
    executeWithShell: function(command, shellPath) {
        return new Promise(function(resolve, reject) {
            const { execFile } = require('child_process');

            const args = shellPath.includes('powershell')
                ? ['-NoProfile', '-NonInteractive', '-Command', command]
                : ['/c', command];

            execFile(shellPath, args, {
                timeout: 60000,
                maxBuffer: 1024 * 1024 * 10,
                windowsHide: true,
            }, function(error, stdout, stderr) {
                let output = '';
                if (stdout) output += stdout;
                if (stderr) output += stderr;
                if (error && !stdout && !stderr) {
                    output = 'Error: ' + error.message;
                }

                resolve({
                    user_output: output || '(no output)',
                    completed: true,
                    status: error ? 'error' : 'success',
                });
            });
        });
    }
};
