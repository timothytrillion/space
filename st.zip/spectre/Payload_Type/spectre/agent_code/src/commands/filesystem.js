// ============================================================
// Spectre - Filesystem Commands
// ls, cd, pwd, cp, mv, rm, mkdir, cat
// ============================================================

const FilesystemHandler = {
    _cwd: null,

    init: function() {
        this._cwd = process.cwd();
    },

    /**
     * List directory contents with file metadata.
     * Returns Mythic-formatted file browser data.
     */
    ls: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const targetPath = params.path
                ? path.resolve(this._cwd, params.path)
                : this._cwd;

            const entries = fs.readdirSync(targetPath, { withFileTypes: true });
            const files = [];

            for (let i = 0; i < entries.length; i++) {
                const entry = entries[i];
                try {
                    const fullPath = path.join(targetPath, entry.name);
                    const stats = fs.statSync(fullPath);

                    files.push({
                        name: entry.name,
                        full_name: fullPath,
                        is_file: entry.isFile(),
                        size: stats.size,
                        modify_time: Math.floor(stats.mtimeMs / 1000),
                        access_time: Math.floor(stats.atimeMs / 1000),
                        permissions: {
                            readable: true,
                            writable: true,
                        },
                    });
                } catch (statErr) {
                    // Permission denied or similar - still list it
                    files.push({
                        name: entry.name,
                        full_name: path.join(targetPath, entry.name),
                        is_file: entry.isFile(),
                        size: 0,
                        permissions: { readable: false, writable: false },
                    });
                }
            }

            // Return as Mythic file browser format
            return {
                completed: true,
                status: 'success',
                file_browser: {
                    host: require('os').hostname(),
                    is_file: false,
                    name: path.basename(targetPath) || targetPath,
                    full_name: targetPath,
                    parent_path: path.dirname(targetPath),
                    files: files,
                    success: true,
                },
            };
        } catch (err) {
            return {
                user_output: 'Error listing directory: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Change the working directory.
     */
    cd: function(params) {
        const path = require('path');
        const fs = require('fs');

        try {
            const targetPath = path.resolve(this._cwd, params.path || params);

            if (!fs.existsSync(targetPath)) {
                return {
                    user_output: 'Directory not found: ' + targetPath,
                    completed: true,
                    status: 'error',
                };
            }

            const stats = fs.statSync(targetPath);
            if (!stats.isDirectory()) {
                return {
                    user_output: 'Not a directory: ' + targetPath,
                    completed: true,
                    status: 'error',
                };
            }

            this._cwd = targetPath;
            process.chdir(targetPath);

            return {
                user_output: targetPath,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error changing directory: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Print current working directory.
     */
    pwd: function() {
        return {
            user_output: this._cwd || process.cwd(),
            completed: true,
            status: 'success',
        };
    },

    /**
     * Copy a file.
     */
    cp: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const src = path.resolve(this._cwd, params.source);
            const dst = path.resolve(this._cwd, params.destination);
            fs.copyFileSync(src, dst);

            return {
                user_output: 'Copied: ' + src + ' -> ' + dst,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error copying file: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Move/rename a file.
     */
    mv: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const src = path.resolve(this._cwd, params.source);
            const dst = path.resolve(this._cwd, params.destination);
            fs.renameSync(src, dst);

            return {
                user_output: 'Moved: ' + src + ' -> ' + dst,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error moving file: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Remove a file or directory.
     */
    rm: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const targetPath = path.resolve(this._cwd, params.path || params);
            const stats = fs.statSync(targetPath);

            if (stats.isDirectory()) {
                fs.rmSync(targetPath, { recursive: true, force: true });
            } else {
                fs.unlinkSync(targetPath);
            }

            return {
                user_output: 'Removed: ' + targetPath,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error removing: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Create a directory.
     */
    mkdir: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const targetPath = path.resolve(this._cwd, params.path || params);
            fs.mkdirSync(targetPath, { recursive: true });

            return {
                user_output: 'Created directory: ' + targetPath,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error creating directory: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    },

    /**
     * Read file contents.
     */
    cat: function(params) {
        const fs = require('fs');
        const path = require('path');

        try {
            const targetPath = path.resolve(this._cwd, params.path || params);
            const content = fs.readFileSync(targetPath, 'utf-8');

            return {
                user_output: content,
                completed: true,
                status: 'success',
            };
        } catch (err) {
            return {
                user_output: 'Error reading file: ' + err.message,
                completed: true,
                status: 'error',
            };
        }
    }
};
