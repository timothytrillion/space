{
  "targets": [
    {
      "target_name": "coff_loader",
      "sources": [
        "src/coff_loader.cpp",
        "src/coff_parser.cpp",
        "src/beacon_api.cpp"
      ],
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")",
        "include"
      ],
      "dependencies": [
        "<!(node -p \"require('node-addon-api').gyp\")"
      ],
      "defines": [
        "NAPI_DISABLE_CPP_EXCEPTIONS",
        "NODE_ADDON_API_ENABLE_MAYBE"
      ],
      "conditions": [
        ["OS=='win'", {
          "libraries": [
            "-lkernel32",
            "-luser32",
            "-ladvapi32",
            "-lws2_32",
            "-lole32",
            "-loleaut32"
          ],
          "msvs_settings": {
            "VCCLCompilerTool": {
              "ExceptionHandling": 1
            }
          }
        }]
      ]
    },
    {
      "target_name": "winapi",
      "sources": [
        "src/winapi_addon.cpp"
      ],
      "include_dirs": [
        "<!@(node -p \"require('node-addon-api').include\")",
        "include"
      ],
      "dependencies": [
        "<!(node -p \"require('node-addon-api').gyp\")"
      ],
      "defines": [
        "NAPI_DISABLE_CPP_EXCEPTIONS",
        "NODE_ADDON_API_ENABLE_MAYBE"
      ],
      "conditions": [
        ["OS=='win'", {
          "libraries": [
            "-lkernel32",
            "-luser32",
            "-ladvapi32",
            "-lws2_32"
          ]
        }]
      ]
    }
  ]
}
