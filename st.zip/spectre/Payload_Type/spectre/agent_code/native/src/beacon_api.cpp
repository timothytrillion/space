/**
 * Spectre - Beacon Compatibility API Implementation
 *
 * Implements the Cobalt Strike Beacon API so existing BOFs can
 * execute unmodified. Output is captured to a global buffer that
 * the Node addon reads after BOF execution completes.
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "../include/beacon.h"

// ============================================================
// Global output capture buffer
// ============================================================

static char*  g_outputBuffer = NULL;
static int    g_outputLength = 0;
static int    g_outputCapacity = 0;
static CRITICAL_SECTION g_outputLock;
static BOOL   g_lockInitialized = FALSE;

static void EnsureLockInit() {
    if (!g_lockInitialized) {
        InitializeCriticalSection(&g_outputLock);
        g_lockInitialized = TRUE;
    }
}

static void AppendOutput(const char* data, int len) {
    EnsureLockInit();
    EnterCriticalSection(&g_outputLock);

    if (g_outputBuffer == NULL) {
        g_outputCapacity = 4096;
        g_outputBuffer = (char*)malloc(g_outputCapacity);
        g_outputLength = 0;
    }

    while (g_outputLength + len + 1 > g_outputCapacity) {
        g_outputCapacity *= 2;
        g_outputBuffer = (char*)realloc(g_outputBuffer, g_outputCapacity);
    }

    memcpy(g_outputBuffer + g_outputLength, data, len);
    g_outputLength += len;
    g_outputBuffer[g_outputLength] = '\0';

    LeaveCriticalSection(&g_outputLock);
}

// ============================================================
// Output capture control
// ============================================================

void BeaconOutputInit(void) {
    EnsureLockInit();
    EnterCriticalSection(&g_outputLock);

    if (g_outputBuffer) {
        free(g_outputBuffer);
    }
    g_outputBuffer = NULL;
    g_outputLength = 0;
    g_outputCapacity = 0;

    LeaveCriticalSection(&g_outputLock);
}

char* BeaconOutputGetData(int* length) {
    if (length) *length = g_outputLength;
    return g_outputBuffer;
}

void BeaconOutputFree(void) {
    EnsureLockInit();
    EnterCriticalSection(&g_outputLock);

    if (g_outputBuffer) {
        free(g_outputBuffer);
        g_outputBuffer = NULL;
    }
    g_outputLength = 0;
    g_outputCapacity = 0;

    LeaveCriticalSection(&g_outputLock);
}

// ============================================================
// Data Parser API
// ============================================================

void BeaconDataParse(datap* parser, char* buffer, int size) {
    if (!parser) return;
    parser->original = buffer;
    parser->buffer = buffer;
    parser->length = size - 4; // Subtract the size prefix
    parser->size = size - 4;

    // Skip the 4-byte total size prefix
    if (size >= 4) {
        parser->buffer = buffer + 4;
    }
}

short BeaconDataShort(datap* parser) {
    if (!parser || parser->length < 2) return 0;

    short value = *(short*)(parser->buffer);
    parser->buffer += 2;
    parser->length -= 2;
    return value;
}

int BeaconDataInt(datap* parser) {
    if (!parser || parser->length < 4) return 0;

    int value = *(int*)(parser->buffer);
    parser->buffer += 4;
    parser->length -= 4;
    return value;
}

char* BeaconDataExtract(datap* parser, int* size) {
    if (!parser || parser->length < 4) {
        if (size) *size = 0;
        return NULL;
    }

    int len = *(int*)(parser->buffer);
    parser->buffer += 4;
    parser->length -= 4;

    if (len > parser->length || len < 0) {
        if (size) *size = 0;
        return NULL;
    }

    char* data = parser->buffer;
    parser->buffer += len;
    parser->length -= len;

    if (size) *size = len;
    return data;
}

char* BeaconDataLongArg(datap* parser, int* size) {
    return BeaconDataExtract(parser, size);
}

// ============================================================
// Format / Output API
// ============================================================

void BeaconFormatAlloc(formatp* format, int maxsz) {
    if (!format) return;
    format->original = (char*)calloc(maxsz, 1);
    format->buffer = format->original;
    format->length = 0;
    format->size = maxsz;
}

void BeaconFormatReset(formatp* format) {
    if (!format) return;
    memset(format->original, 0, format->size);
    format->buffer = format->original;
    format->length = 0;
}

void BeaconFormatFree(formatp* format) {
    if (!format) return;
    if (format->original) {
        free(format->original);
        format->original = NULL;
    }
    format->buffer = NULL;
    format->length = 0;
    format->size = 0;
}

void BeaconFormatAppend(formatp* format, char* text, int len) {
    if (!format || !text) return;
    if (format->length + len > format->size) return;

    memcpy(format->buffer + format->length, text, len);
    format->length += len;
}

void BeaconFormatPrintf(formatp* format, char* fmt, ...) {
    if (!format || !fmt) return;

    va_list args;
    va_start(args, fmt);

    int remaining = format->size - format->length;
    int written = vsnprintf(
        format->buffer + format->length,
        remaining,
        fmt,
        args
    );

    if (written > 0 && written < remaining) {
        format->length += written;
    }

    va_end(args);
}

char* BeaconFormatToString(formatp* format, int* size) {
    if (!format) {
        if (size) *size = 0;
        return NULL;
    }
    if (size) *size = format->length;
    return format->original;
}

void BeaconFormatInt(formatp* format, int value) {
    if (!format) return;
    if (format->length + 4 > format->size) return;

    *(int*)(format->buffer + format->length) = value;
    format->length += 4;
}

void BeaconPrintf(int type, char* fmt, ...) {
    if (!fmt) return;

    char buffer[8192];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buffer, sizeof(buffer) - 1, fmt, args);
    va_end(args);

    if (len > 0) {
        buffer[len] = '\0';
        AppendOutput(buffer, len);
        AppendOutput("\n", 1);
    }
}

void BeaconOutput(int type, char* data, int len) {
    if (!data || len <= 0) return;
    AppendOutput(data, len);
}

// ============================================================
// Token / Process API (stubs for compatibility)
// ============================================================

BOOL BeaconUseToken(HANDLE token) {
    return ImpersonateLoggedOnUser(token);
}

void BeaconRevertToken(void) {
    RevertToSelf();
}

BOOL BeaconIsAdmin(void) {
    BOOL isAdmin = FALSE;
    PSID adminGroup = NULL;

    SID_IDENTIFIER_AUTHORITY ntAuthority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(
            &ntAuthority, 2,
            SECURITY_BUILTIN_DOMAIN_RID,
            DOMAIN_ALIAS_RID_ADMINS,
            0, 0, 0, 0, 0, 0,
            &adminGroup)) {
        CheckTokenMembership(NULL, adminGroup, &isAdmin);
        FreeSid(adminGroup);
    }

    return isAdmin;
}

void BeaconGetSpawnTo(BOOL x86, char* buffer, int length) {
    if (x86) {
        strncpy(buffer, "C:\\Windows\\SysWOW64\\rundll32.exe", length);
    } else {
        strncpy(buffer, "C:\\Windows\\System32\\rundll32.exe", length);
    }
}

void BeaconInjectTemporaryProcess(
    PROCESS_INFORMATION* pInfo,
    char* payload,
    int payloadLen,
    int offset,
    char* arg,
    int argLen
) {
    // Stub: In this JS-based agent, process injection is handled
    // differently. This exists for BOF API compatibility.
    BeaconPrintf(CALLBACK_ERROR,
        "BeaconInjectTemporaryProcess: Not implemented in JS agent. "
        "Use native Node addon for injection.");
}

BOOL BeaconSpawnTemporaryProcess(
    BOOL x86,
    BOOL ignoreToken,
    STARTUPINFOA* si,
    PROCESS_INFORMATION* pi
) {
    char spawnTo[MAX_PATH];
    BeaconGetSpawnTo(x86, spawnTo, MAX_PATH);

    return CreateProcessA(
        NULL,
        spawnTo,
        NULL,
        NULL,
        TRUE,
        CREATE_NO_WINDOW | CREATE_SUSPENDED,
        NULL,
        NULL,
        si,
        pi
    );
}

void BeaconCleanupProcess(PROCESS_INFORMATION* pi) {
    if (!pi) return;
    if (pi->hThread) {
        TerminateThread(pi->hThread, 0);
        CloseHandle(pi->hThread);
    }
    if (pi->hProcess) {
        TerminateProcess(pi->hProcess, 0);
        CloseHandle(pi->hProcess);
    }
}

// ============================================================
// Dynamic resolution
// ============================================================

FARPROC BeaconGetProcAddress(HMODULE hModule, const char* lpProcName) {
    return GetProcAddress(hModule, lpProcName);
}
