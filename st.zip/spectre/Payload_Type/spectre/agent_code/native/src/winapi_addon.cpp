/**
 * Spectre - Windows API Native Addon
 *
 * Provides direct Windows API access from JavaScript/Node.js
 * without requiring FFI libraries like node-ffi-napi.
 * Loads as a normal .node native module under the Electron process.
 */

#include <napi.h>
#include <windows.h>
#include <tlhelp32.h>
#include <sddl.h>
#include <lm.h>

// ============================================================
// Process enumeration (richer than WMIC-based approach)
// ============================================================

Napi::Value GetProcessList(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();

    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot == INVALID_HANDLE_VALUE) {
        Napi::Error::New(env, "CreateToolhelp32Snapshot failed")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    PROCESSENTRY32W pe32;
    pe32.dwSize = sizeof(PROCESSENTRY32W);

    Napi::Array result = Napi::Array::New(env);
    uint32_t index = 0;

    if (Process32FirstW(hSnapshot, &pe32)) {
        do {
            Napi::Object proc = Napi::Object::New(env);
            proc.Set("pid", Napi::Number::New(env, pe32.th32ProcessID));
            proc.Set("ppid", Napi::Number::New(env, pe32.th32ParentProcessID));
            proc.Set("threads", Napi::Number::New(env, pe32.cntThreads));

            // Convert wide string to UTF-8
            char exeName[MAX_PATH];
            WideCharToMultiByte(CP_UTF8, 0, pe32.szExeFile, -1,
                                exeName, MAX_PATH, NULL, NULL);
            proc.Set("name", Napi::String::New(env, exeName));

            result.Set(index++, proc);
        } while (Process32NextW(hSnapshot, &pe32));
    }

    CloseHandle(hSnapshot);
    return result;
}

// ============================================================
// Token information
// ============================================================

Napi::Value GetTokenInfo(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();

    HANDLE hToken;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken)) {
        return env.Null();
    }

    Napi::Object result = Napi::Object::New(env);

    // Get token user
    DWORD tokenInfoLen = 0;
    GetTokenInformation(hToken, TokenUser, NULL, 0, &tokenInfoLen);
    if (tokenInfoLen > 0) {
        BYTE* tokenInfo = new BYTE[tokenInfoLen];
        if (GetTokenInformation(hToken, TokenUser, tokenInfo, tokenInfoLen, &tokenInfoLen)) {
            TOKEN_USER* tokenUser = (TOKEN_USER*)tokenInfo;
            LPSTR sidStr = NULL;
            if (ConvertSidToStringSidA(tokenUser->User.Sid, &sidStr)) {
                result.Set("sid", Napi::String::New(env, sidStr));
                LocalFree(sidStr);
            }
        }
        delete[] tokenInfo;
    }

    // Get integrity level
    tokenInfoLen = 0;
    GetTokenInformation(hToken, TokenIntegrityLevel, NULL, 0, &tokenInfoLen);
    if (tokenInfoLen > 0) {
        BYTE* tokenInfo = new BYTE[tokenInfoLen];
        if (GetTokenInformation(hToken, TokenIntegrityLevel, tokenInfo, tokenInfoLen, &tokenInfoLen)) {
            TOKEN_MANDATORY_LABEL* tml = (TOKEN_MANDATORY_LABEL*)tokenInfo;
            DWORD integrityLevel = *GetSidSubAuthority(
                tml->Label.Sid,
                (DWORD)(UCHAR)(*GetSidSubAuthorityCount(tml->Label.Sid) - 1)
            );

            if (integrityLevel >= SECURITY_MANDATORY_SYSTEM_RID) {
                result.Set("integrity", Napi::String::New(env, "System"));
                result.Set("integrityLevel", Napi::Number::New(env, 4));
            } else if (integrityLevel >= SECURITY_MANDATORY_HIGH_RID) {
                result.Set("integrity", Napi::String::New(env, "High"));
                result.Set("integrityLevel", Napi::Number::New(env, 3));
            } else if (integrityLevel >= SECURITY_MANDATORY_MEDIUM_RID) {
                result.Set("integrity", Napi::String::New(env, "Medium"));
                result.Set("integrityLevel", Napi::Number::New(env, 2));
            } else {
                result.Set("integrity", Napi::String::New(env, "Low"));
                result.Set("integrityLevel", Napi::Number::New(env, 1));
            }
        }
        delete[] tokenInfo;
    }

    // Check if elevated
    TOKEN_ELEVATION elevation;
    tokenInfoLen = sizeof(TOKEN_ELEVATION);
    if (GetTokenInformation(hToken, TokenElevation, &elevation, sizeof(elevation), &tokenInfoLen)) {
        result.Set("elevated", Napi::Boolean::New(env, elevation.TokenIsElevated != 0));
    }

    CloseHandle(hToken);
    return result;
}

// ============================================================
// Named pipe operations (for output redirection)
// ============================================================

Napi::Value CreateNamedPipeServer(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();

    if (info.Length() < 1 || !info[0].IsString()) {
        Napi::TypeError::New(env, "Expected pipe name string")
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    std::string pipeName = "\\\\.\\pipe\\" + info[0].As<Napi::String>().Utf8Value();

    HANDLE hPipe = CreateNamedPipeA(
        pipeName.c_str(),
        PIPE_ACCESS_DUPLEX,
        PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
        1,          // Max instances
        4096,       // Out buffer size
        4096,       // In buffer size
        0,          // Default timeout
        NULL        // Default security
    );

    if (hPipe == INVALID_HANDLE_VALUE) {
        Napi::Error::New(env, "CreateNamedPipe failed: " + std::to_string(GetLastError()))
            .ThrowAsJavaScriptException();
        return env.Null();
    }

    // Return handle as external
    return Napi::Number::New(env, (double)(uintptr_t)hPipe);
}

// ============================================================
// Electron app discovery
// ============================================================

Napi::Value FindElectronApps(const Napi::CallbackInfo& info) {
    Napi::Env env = info.Env();
    Napi::Array result = Napi::Array::New(env);
    uint32_t index = 0;

    // Common Electron app locations
    char localAppData[MAX_PATH];
    if (!GetEnvironmentVariableA("LOCALAPPDATA", localAppData, MAX_PATH)) {
        return result;
    }

    const char* knownApps[] = {
        "slack", "Discord", "Microsoft\\Teams",
        "Programs\\Microsoft VS Code", NULL
    };

    for (int i = 0; knownApps[i] != NULL; i++) {
        char searchPath[MAX_PATH * 2];
        snprintf(searchPath, sizeof(searchPath), "%s\\%s\\resources\\app.asar",
                 localAppData, knownApps[i]);

        if (GetFileAttributesA(searchPath) != INVALID_FILE_ATTRIBUTES) {
            Napi::Object app = Napi::Object::New(env);
            app.Set("name", Napi::String::New(env, knownApps[i]));
            app.Set("asarPath", Napi::String::New(env, searchPath));

            // Check for unpacked directory
            char unpackedPath[MAX_PATH * 2];
            snprintf(unpackedPath, sizeof(unpackedPath),
                     "%s\\%s\\resources\\app.asar.unpacked",
                     localAppData, knownApps[i]);

            app.Set("hasUnpacked",
                Napi::Boolean::New(env,
                    GetFileAttributesA(unpackedPath) != INVALID_FILE_ATTRIBUTES));
            app.Set("unpackedPath", Napi::String::New(env, unpackedPath));

            result.Set(index++, app);
        }
    }

    return result;
}

// ============================================================
// Module initialization
// ============================================================

Napi::Object Init(Napi::Env env, Napi::Object exports) {
    exports.Set("getProcessList",        Napi::Function::New(env, GetProcessList));
    exports.Set("getTokenInfo",          Napi::Function::New(env, GetTokenInfo));
    exports.Set("createNamedPipe",       Napi::Function::New(env, CreateNamedPipeServer));
    exports.Set("findElectronApps",      Napi::Function::New(env, FindElectronApps));
    return exports;
}

NODE_API_MODULE(winapi, Init)
