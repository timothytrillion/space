/**
 * Spectre - Beacon Compatibility API
 *
 * Provides Cobalt Strike BOF-compatible API functions so existing
 * BOFs (TrustedSec SA-BOF, etc.) can execute without modification.
 * These functions capture BOF output and marshal it back to JavaScript.
 */

#ifndef SPECTRE_BEACON_H
#define SPECTRE_BEACON_H

#include <windows.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// ============================================================
// Data Parser API
// ============================================================

typedef struct {
    char* original;
    char* buffer;
    int   length;
    int   size;
} datap;

/**
 * Initialize a data parser on a buffer.
 */
void BeaconDataParse(datap* parser, char* buffer, int size);

/**
 * Extract a short (2 bytes) from the parser.
 */
short BeaconDataShort(datap* parser);

/**
 * Extract an int (4 bytes) from the parser.
 */
int BeaconDataInt(datap* parser);

/**
 * Extract a length-prefixed byte buffer from the parser.
 */
char* BeaconDataExtract(datap* parser, int* size);

/**
 * Extract a length-prefixed string from the parser.
 */
char* BeaconDataLongArg(datap* parser, int* size);

// ============================================================
// Output API
// ============================================================

#define CALLBACK_OUTPUT      0x00
#define CALLBACK_OUTPUT_OEM  0x1e
#define CALLBACK_ERROR       0x0d
#define CALLBACK_OUTPUT_UTF8 0x20

typedef struct {
    char* original;
    char* buffer;
    int   length;
    int   size;
} formatp;

/**
 * Initialize a format buffer for output.
 */
void BeaconFormatAlloc(formatp* format, int maxsz);

/**
 * Reset a format buffer.
 */
void BeaconFormatReset(formatp* format);

/**
 * Free a format buffer.
 */
void BeaconFormatFree(formatp* format);

/**
 * Append formatted output.
 */
void BeaconFormatAppend(formatp* format, char* text, int len);

/**
 * Printf-style output to format buffer.
 */
void BeaconFormatPrintf(formatp* format, char* fmt, ...);

/**
 * Convert format buffer to string.
 */
char* BeaconFormatToString(formatp* format, int* size);

/**
 * Append an int to format buffer.
 */
void BeaconFormatInt(formatp* format, int value);

/**
 * Send output to the operator.
 */
void BeaconPrintf(int type, char* fmt, ...);

/**
 * Send raw output data.
 */
void BeaconOutput(int type, char* data, int len);

// ============================================================
// Token / Process API
// ============================================================

/**
 * Use a token for subsequent operations.
 */
BOOL BeaconUseToken(HANDLE token);

/**
 * Revert to the original process token.
 */
void BeaconRevertToken(void);

/**
 * Check if the agent is running in a 64-bit process.
 */
BOOL BeaconIsAdmin(void);

/**
 * Get the agent's current working directory.
 */
void BeaconGetSpawnTo(BOOL x86, char* buffer, int length);

/**
 * Inject into a spawned temporary process.
 */
void BeaconInjectTemporaryProcess(
    PROCESS_INFORMATION* pInfo,
    char* payload,
    int payloadLen,
    int offset,
    char* arg,
    int argLen
);

/**
 * Spawn a temporary process for injection.
 */
BOOL BeaconSpawnTemporaryProcess(
    BOOL x86,
    BOOL ignoreToken,
    STARTUPINFOA* si,
    PROCESS_INFORMATION* pi
);

/**
 * Clean up a spawned process.
 */
void BeaconCleanupProcess(PROCESS_INFORMATION* pi);

// ============================================================
// Internal API (for COFF loader)
// ============================================================

/**
 * Dynamically resolve a Win32 API function by module + name.
 * Used by the COFF loader for symbol resolution.
 */
FARPROC BeaconGetProcAddress(HMODULE hModule, const char* lpProcName);

// ============================================================
// Output capture (internal to addon)
// ============================================================

/**
 * Initialize the output capture buffer.
 * Called before BOF execution.
 */
void BeaconOutputInit(void);

/**
 * Get the captured output after BOF execution.
 */
char* BeaconOutputGetData(int* length);

/**
 * Free the captured output buffer.
 */
void BeaconOutputFree(void);

#ifdef __cplusplus
}
#endif

#endif // SPECTRE_BEACON_H
