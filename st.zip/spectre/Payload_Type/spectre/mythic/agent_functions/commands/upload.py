"""Spectre - upload (target -> Mythic) command definition."""
from mythic_container.MythicCommandBase import *


class UploadArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = [
            CommandParameter(
                name="file",
                type=ParameterType.String,
                description="Path of the file on the target to upload to Mythic",
                parameter_group_info=[ParameterGroupInfo(required=True)],
            ),
        ]

    async def parse_arguments(self):
        if len(self.command_line) > 0:
            if self.command_line[0] == "{":
                self.load_args_from_json_string(self.command_line)
            else:
                self.add_arg("file", self.command_line)


class UploadCommand(CommandBase):
    cmd = "upload"
    needs_admin = False
    help_cmd = "upload [file_path]"
    description = "Upload a file from the target machine to the Mythic server."
    version = 1
    author = "spectre-dev"
    argument_class = UploadArguments
    attackmapping = ["T1041"]  # Exfiltration Over C2 Channel

    async def create_go_tasking(self, taskData):
        response = PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )
        response.DisplayParams = taskData.args.get_arg("file")
        return response

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
