"""Spectre - whoami command definition."""
from mythic_container.MythicCommandBase import *


class WhoamiArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = []

    async def parse_arguments(self):
        pass


class WhoamiCommand(CommandBase):
    cmd = "whoami"
    needs_admin = False
    help_cmd = "whoami"
    description = "Get current user identity, process info, and system details."
    version = 1
    author = "spectre-dev"
    argument_class = WhoamiArguments
    attackmapping = ["T1033"]  # System Owner/User Discovery

    async def create_go_tasking(self, taskData):
        return PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
