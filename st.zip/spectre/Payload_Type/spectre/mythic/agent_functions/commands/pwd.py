"""Spectre - pwd (print working directory) command definition."""
from mythic_container.MythicCommandBase import *


class PwdArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = []

    async def parse_arguments(self):
        pass


class PwdCommand(CommandBase):
    cmd = "pwd"
    needs_admin = False
    help_cmd = "pwd"
    description = "Print the agent's current working directory."
    version = 1
    author = "spectre-dev"
    argument_class = PwdArguments
    attackmapping = []

    async def create_go_tasking(self, taskData):
        return PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
