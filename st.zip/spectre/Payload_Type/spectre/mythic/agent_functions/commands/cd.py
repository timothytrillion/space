"""Spectre - cd (change directory) command definition."""
from mythic_container.MythicCommandBase import *


class CdArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = [
            CommandParameter(
                name="path",
                type=ParameterType.String,
                description="Directory to change to",
                parameter_group_info=[ParameterGroupInfo(required=True)],
            ),
        ]

    async def parse_arguments(self):
        if len(self.command_line) > 0:
            if self.command_line[0] == "{":
                self.load_args_from_json_string(self.command_line)
            else:
                self.add_arg("path", self.command_line)


class CdCommand(CommandBase):
    cmd = "cd"
    needs_admin = False
    help_cmd = "cd [path]"
    description = "Change the agent's working directory."
    version = 1
    author = "spectre-dev"
    argument_class = CdArguments
    attackmapping = []

    async def create_go_tasking(self, taskData):
        response = PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )
        response.DisplayParams = taskData.args.get_arg("path")
        return response

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
