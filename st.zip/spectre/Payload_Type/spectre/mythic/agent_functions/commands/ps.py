"""Spectre - ps (process listing) command definition."""
from mythic_container.MythicCommandBase import *


class PsArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = []

    async def parse_arguments(self):
        pass


class PsCommand(CommandBase):
    cmd = "ps"
    needs_admin = False
    help_cmd = "ps"
    description = "List running processes with PID, PPID, and name."
    version = 1
    author = "spectre-dev"
    argument_class = PsArguments
    attackmapping = ["T1057"]  # Process Discovery
    supported_ui_features = ["process_browser:list"]

    async def create_go_tasking(self, taskData):
        return PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
