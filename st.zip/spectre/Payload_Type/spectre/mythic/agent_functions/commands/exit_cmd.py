"""Spectre - exit command definition."""
from mythic_container.MythicCommandBase import *


class ExitArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = []

    async def parse_arguments(self):
        pass


class ExitCommand(CommandBase):
    cmd = "exit"
    needs_admin = False
    help_cmd = "exit"
    description = "Terminate the agent. The host Electron application continues running normally."
    version = 1
    author = "spectre-dev"
    argument_class = ExitArguments
    attackmapping = []

    async def create_go_tasking(self, taskData):
        return PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
