"""Spectre - BOF (Beacon Object File) execution command definition."""
from mythic_container.MythicCommandBase import *


class BofArguments(TaskArguments):
    def __init__(self, command_line, **kwargs):
        super().__init__(command_line, **kwargs)
        self.args = [
            CommandParameter(
                name="bof_file",
                type=ParameterType.File,
                description="COFF object file (.o) to execute",
                parameter_group_info=[ParameterGroupInfo(required=True)],
            ),
            CommandParameter(
                name="function_name",
                type=ParameterType.String,
                description="Entry point function name",
                default_value="go",
                parameter_group_info=[ParameterGroupInfo(required=False)],
            ),
            CommandParameter(
                name="arguments",
                type=ParameterType.String,
                description=(
                    "BOF arguments as JSON array: "
                    '[{"type":"string","value":"hello"}, {"type":"int","value":42}]'
                ),
                default_value="[]",
                parameter_group_info=[ParameterGroupInfo(required=False)],
            ),
            CommandParameter(
                name="timeout",
                type=ParameterType.Number,
                description="Execution timeout in milliseconds",
                default_value=30000,
                parameter_group_info=[ParameterGroupInfo(required=False)],
            ),
        ]

    async def parse_arguments(self):
        if len(self.command_line) > 0:
            self.load_args_from_json_string(self.command_line)


class BofCommand(CommandBase):
    cmd = "bof"
    needs_admin = False
    help_cmd = "bof --bof_file [file] --function_name go --arguments '[]'"
    description = (
        "Execute a Beacon Object File (BOF/COFF) via the native COFF loader addon. "
        "Compatible with Cobalt Strike BOFs and Sliver armory BOFs. "
        "Requires the coff_loader native module to be loaded first (use 'load' command). "
        "The BOF executes within the Electron process - no process injection needed."
    )
    version = 1
    author = "spectre-dev"
    argument_class = BofArguments
    attackmapping = ["T1106"]  # Native API

    async def create_go_tasking(self, taskData):
        response = PTTaskCreateTaskingMessageResponse(
            TaskID=taskData.Task.ID, Success=True
        )
        func = taskData.args.get_arg("function_name")
        response.DisplayParams = f"entry: {func}"
        return response

    async def process_response(self, task, response):
        return PTTaskProcessResponseMessageResponse(
            TaskID=task.Task.ID, Success=True
        )
